/**
 * On-Chain Attestation State Manager
 *
 * This module manages the lifecycle of compliance attestations directly on the
 * Solana blockchain for maximum transparency and auditability.
 *
 * ## Overview
 *
 * The Attestation State Manager:
 * - Creates and manages KYC attestations
 * - Tracks attestation status transitions
 * - Handles expiration and revocation
 * - Provides transparent verification
 * - Emits events for state changes
 *
 * ## Attestation Lifecycle
 *
 * 1. Pending: Initial state when created
 * 2. Active: Successfully verified and valid
 * 3. Suspended: Temporarily paused
 * 4. Revoked: Permanently invalidated
 * 5. Expired: Past expiration date
 *
 * ## Usage
 *
 * ```typescript
 * import { AttestationStateManager, AttestationStatus } from './attestation-state-manager';
 *
 * const manager = new AttestationStateManager(connection, programId);
 * await manager.createAttestation(wallet, provider, kycLevel);
 * const status = await manager.getAttestationStatus(wallet);
 * ```
 */

import { Connection, PublicKey, Transaction, SystemProgram, Keypair } from '@solana/web3.js';
import { BN } from '@coral-xyz/anchor';

/**
 * Attestation status
 */
export enum AttestationStatus {
  /** Initial state - being verified */
  Pending = 0,
  /** Active and valid */
  Active = 1,
  /** Temporarily suspended */
  Suspended = 2,
  /** Permanently revoked */
  Revoked = 3,
  /** Past expiration date */
  Expired = 4,
}

/**
 * KYC verification level
 */
export enum KycLevel {
  /** No verification */
  None = 0,
  /** Basic - email/phone only */
  Basic = 1,
  /** Standard - ID verification */
  Standard = 2,
  /** Enhanced - full due diligence */
  Enhanced = 3,
}

/**
 * Attestation data structure
 */
export interface Attestation {
  /** Attestation public key */
  pubkey: PublicKey;
  /** Wallet address */
  wallet: PublicKey;
  /** KYC provider public key */
  provider: PublicKey;
  /** Attestation status */
  status: AttestationStatus;
  /** KYC level */
  level: KycLevel;
  /** Expiration timestamp (Unix) */
  expiresAt: number;
  /** Creation timestamp (Unix) */
  createdAt: number;
  /** Last update timestamp (Unix) */
  updatedAt: number;
  /** Attestation metadata */
  metadata: Record<string, string>;
  /** Version */
  version: number;
}

/**
 * Attestation creation request
 */
export interface CreateAttestationRequest {
  /** Wallet address */
  wallet: PublicKey;
  /** KYC provider */
  provider: PublicKey;
  /** KYC level */
  level: KycLevel;
  /** Validity duration in seconds */
  validityDuration: number;
  /** Additional metadata */
  metadata?: Record<string, string>;
}

/**
 * Attestation update request
 */
export interface UpdateAttestationRequest {
  /** Attestation public key */
  attestation: PublicKey;
  /** New status */
  status?: AttestationStatus;
  /** New expiration */
  expiresAt?: number;
  /** New KYC level */
  level?: KycLevel;
  /** Metadata to update */
  metadata?: Record<string, string>;
}

/**
 * Attestation verification result
 */
export interface VerificationResult {
  /** Whether attestation is valid */
  isValid: boolean;
  /** Current status */
  status: AttestationStatus;
  /** KYC level */
  level: KycLevel;
  /** Expiration time */
  expiresAt: number;
  /** Provider */
  provider: PublicKey;
  /** Verification timestamp */
  verifiedAt: number;
  /** Failure reason if invalid */
  failureReason?: string;
}

/**
 * Attestation history entry
 */
export interface AttestationHistoryEntry {
  /** Entry ID */
  id: string;
  /** Attestation address */
  attestation: PublicKey;
  /** Previous status */
  previousStatus: AttestationStatus;
  /** New status */
  newStatus: AttestationStatus;
  /** Actor who made the change */
  actor: PublicKey;
  /** Timestamp */
  timestamp: number;
  /** Reason for change */
  reason: string;
  /** Transaction signature */
  txSignature?: string;
}

/**
 * Attestation statistics
 */
export interface AttestationStats {
  /** Total attestations */
  total: number;
  /** Active attestations */
  active: number;
  /** Pending attestations */
  pending: number;
  /** Expired attestations */
  expired: number;
  /** Revoked attestations */
  revoked: number;
  /** Suspended attestations */
  suspended: number;
  /** By KYC level */
  byLevel: Record<KycLevel, number>;
  /** By provider */
  byProvider: Record<string, number>;
}

/**
 * On-Chain Attestation State Manager
 */
export class AttestationStateManager {
  private connection: Connection;
  private programId: PublicKey;
  private authority: Keypair | null = null;

  /**
   * Create a new Attestation State Manager
   */
  constructor(connection: Connection, programId: PublicKey) {
    this.connection = connection;
    this.programId = programId;
  }

  /**
   * Set authority keypair for transactions
   */
  setAuthority(authority: Keypair): void {
    this.authority = authority;
  }

  /**
   * Create a new attestation
   */
  async createAttestation(request: CreateAttestationRequest): Promise<PublicKey> {
    const now = Date.now();
    const expiresAt = now + (request.validityDuration * 1000);

    // In production, this would create the actual on-chain account
    // For now, simulate the creation
    console.log(`[AttestationManager] Creating attestation for ${request.wallet.toString()}`);
    console.log(`[AttestationManager] Provider: ${request.provider.toString()}`);
    console.log(`[AttestationManager] Level: ${KycLevel[request.level]}`);
    console.log(`[AttestationManager] Expires: ${new Date(expiresAt).toISOString()}`);

    // Generate attestation address
    const attestationPubkey = await this.deriveAttestationAddress(request.wallet, request.provider);

    // In production: create transaction with createAttestation instruction
    // const transaction = new Transaction();
    // transaction.add(
    //   createAttestationInstruction({
    //     wallet: request.wallet,
    //     provider: request.provider,
    //     level: request.level,
    //     expiresAt: new BN(expiresAt / 1000),
    //     metadata: request.metadata || {},
    //   }, { signers: [this.authority] })
    // );
    // await this.connection.sendTransaction(transaction, [this.authority]);

    return attestationPubkey;
  }

  /**
   * Update attestation status
   */
  async updateAttestation(request: UpdateAttestationRequest): Promise<void> {
    console.log(`[AttestationManager] Updating attestation ${request.attestation.toString()}`);

    if (request.status !== undefined) {
      console.log(`[AttestationManager] New status: ${AttestationStatus[request.status]}`);
    }

    if (request.level !== undefined) {
      console.log(`[AttestationManager] New level: ${KycLevel[request.level]}`);
    }

    if (request.expiresAt !== undefined) {
      console.log(`[AttestationManager] New expiration: ${new Date(request.expiresAt).toISOString()}`);
    }

    // In production: send update transaction
  }

  /**
   * Suspend an attestation
   */
  async suspendAttestation(
    attestation: PublicKey,
    reason: string
  ): Promise<void> {
    console.log(`[AttestationManager] Suspending attestation ${attestation.toString()}`);
    console.log(`[AttestationManager] Reason: ${reason}`);

    await this.updateAttestation({
      attestation,
      status: AttestationStatus.Suspended,
    });
  }

  /**
   * Revoke an attestation
   */
  async revokeAttestation(
    attestation: PublicKey,
    reason: string
  ): Promise<void> {
    console.log(`[AttestationManager] Revoking attestation ${attestation.toString()}`);
    console.log(`[AttestationManager] Reason: ${reason}`);

    await this.updateAttestation({
      attestation,
      status: AttestationStatus.Revoked,
    });
  }

  /**
   * Reactivate a suspended attestation
   */
  async reactivateAttestation(attestation: PublicKey): Promise<void> {
    console.log(`[AttestationManager] Reactivating attestation ${attestation.toString()}`);

    await this.updateAttestation({
      attestation,
      status: AttestationStatus.Active,
    });
  }

  /**
   * Renew an expired attestation
   */
  async renewAttestation(
    attestation: PublicKey,
    newDuration: number
  ): Promise<void> {
    const newExpiration = Date.now() + (newDuration * 1000);

    console.log(`[AttestationManager] Renewing attestation ${attestation.toString()}`);
    console.log(`[AttestationManager] New expiration: ${new Date(newExpiration).toISOString()}`);

    await this.updateAttestation({
      attestation,
      expiresAt: Math.floor(newExpiration / 1000),
    });
  }

  /**
   * Get attestation status
   */
  async getAttestationStatus(wallet: PublicKey): Promise<VerificationResult | null> {
    // In production, this would fetch from chain
    // For demo, return mock data
    console.log(`[AttestationManager] Getting status for ${wallet.toString()}`);

    return {
      isValid: true,
      status: AttestationStatus.Active,
      level: KycLevel.Standard,
      expiresAt: Date.now() + (86400 * 1000), // 1 day
      provider: new PublicKey('11111111111111111111111111111111'),
      verifiedAt: Date.now(),
    };
  }

  /**
   * Verify attestation validity
   */
  async verifyAttestation(wallet: PublicKey): Promise<VerificationResult> {
    const status = await this.getAttestationStatus(wallet);

    if (!status) {
      return {
        isValid: false,
        status: AttestationStatus.Pending,
        level: KycLevel.None,
        expiresAt: 0,
        provider: PublicKey.default,
        verifiedAt: Date.now(),
        failureReason: 'No attestation found',
      };
    }

    // Check expiration
    const now = Date.now();
    if (status.expiresAt < now) {
      return {
        ...status,
        isValid: false,
        status: AttestationStatus.Expired,
        failureReason: 'Attestation has expired',
      };
    }

    // Check status
    if (status.status !== AttestationStatus.Active) {
      return {
        ...status,
        isValid: false,
        failureReason: `Attestation status is ${AttestationStatus[status.status]}`,
      };
    }

    return status;
  }

  /**
   * Get attestation by wallet and provider
   */
  async getAttestation(
    wallet: PublicKey,
    provider: PublicKey
  ): Promise<Attestation | null> {
    const attestationPubkey = await this.deriveAttestationAddress(wallet, provider);

    console.log(`[AttestationManager] Fetching attestation: ${attestationPubkey.toString()}`);

    // In production, fetch account data
    return null;
  }

  /**
   * Get all attestations for a wallet
   */
  async getAttestationsByWallet(wallet: PublicKey): Promise<Attestation[]> {
    console.log(`[AttestationManager] Fetching all attestations for ${wallet.toString()}`);

    // In production: query all attestation accounts for wallet
    return [];
  }

  /**
   * Get attestation history
   */
  async getAttestationHistory(
    attestation: PublicKey,
    limit: number = 50
  ): Promise<AttestationHistoryEntry[]> {
    console.log(`[AttestationManager] Fetching history for ${attestation.toString()}`);

    // In production: query history from account or logs
    return [];
  }

  /**
   * Batch verify multiple wallets
   */
  async batchVerify(wallets: PublicKey[]): Promise<Map<PublicKey, VerificationResult>> {
    const results = new Map<PublicKey, VerificationResult>();

    // Process in batches
    const batchSize = 10;
    for (let i = 0; i < wallets.length; i += batchSize) {
      const batch = wallets.slice(i, i + batchSize);

      const batchResults = await Promise.all(
        batch.map(wallet => this.verifyAttestation(wallet))
      );

      batch.forEach((wallet, index) => {
        results.set(wallet, batchResults[index]);
      });

      // Rate limiting
      if (i + batchSize < wallets.length) {
        await this.delay(50);
      }
    }

    return results;
  }

  /**
   * Get attestation statistics
   */
  async getStats(): Promise<AttestationStats> {
    // In production: aggregate from chain
    return {
      total: 0,
      active: 0,
      pending: 0,
      expired: 0,
      revoked: 0,
      suspended: 0,
      byLevel: {
        [KycLevel.None]: 0,
        [KycLevel.Basic]: 0,
        [KycLevel.Standard]: 0,
        [KycLevel.Enhanced]: 0,
      },
      byProvider: {},
    };
  }

  /**
   * Expire old attestations (maintenance function)
   */
  async expireOldAttestations(): Promise<number> {
    console.log('[AttestationManager] Running expiration maintenance');

    // In production: find and expire attestations past their expiration date
    return 0;
  }

  /**
   * Derive attestation address
   */
  async deriveAttestationAddress(
    wallet: PublicKey,
    provider: PublicKey
  ): Promise<PublicKey> {
    // In production: derive using Program Derived Address (PDA)
    // seeds = [b"attestation", wallet.as_bytes(), provider.as_bytes()]
    // pubkey = PublicKey.findProgramAddressSync(seeds, programId)[0]

    // Placeholder: return a mock address
    const seed = wallet.toString().slice(0, 32) + provider.toString().slice(0, 32);
    return new PublicKey(seed);
  }

  /**
   * Subscribe to attestation changes
   */
  subscribeToAttestation(
    wallet: PublicKey,
    callback: (attestation: Attestation | null) => void
  ): number {
    console.log(`[AttestationManager] Subscribing to ${wallet.toString()}`);

    // In production: subscribe to account changes
    // return this.connection.onAccountChange(attestationPubkey, callback);

    return 0; // Subscription ID
  }

  /**
   * Unsubscribe from attestation changes
   */
  unsubscribe(subscriptionId: number): void {
    console.log(`[AttestationManager] Unsubscribing ${subscriptionId}`);

    // In production:
    // this.connection.removeAccountChangeListener(subscriptionId);
  }

  /**
   * Get attestation program ID
   */
  getProgramId(): PublicKey {
    return this.programId;
  }

  /**
   * Utility delay function
   */
  private delay(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

/**
 * Attestation verification helper
 */
export class AttestationVerifier {
  private manager: AttestationStateManager;

  constructor(manager: AttestationStateManager) {
    this.manager = manager;
  }

  /**
   * Verify for transfer
   */
  async verifyForTransfer(wallet: PublicKey, minLevel: KycLevel): Promise<VerificationResult> {
    const result = await this.manager.verifyAttestation(wallet);

    if (!result.isValid) {
      return result;
    }

    if (result.level < minLevel) {
      return {
        ...result,
        isValid: false,
        failureReason: `Insufficient KYC level: ${KycLevel[result.level]} < ${KycLevel[minLevel]}`,
      };
    }

    return result;
  }

  /**
   * Verify for high-value transfer
   */
  async verifyForHighValueTransfer(wallet: PublicKey): Promise<VerificationResult> {
    return this.verifyForTransfer(wallet, KycLevel.Standard);
  }

  /**
   * Verify for RWA transaction
   */
  async verifyForRWA(wallet: PublicKey): Promise<VerificationResult> {
    return this.verifyForTransfer(wallet, KycLevel.Enhanced);
  }

  /**
   * Batch verify for transfer
   */
  async batchVerifyForTransfer(
    wallets: PublicKey[],
    minLevel: KycLevel
  ): Promise<Map<PublicKey, VerificationResult>> {
    const results = await this.manager.batchVerify(wallets);

    // Apply minimum level filter
    for (const [wallet, result] of results) {
      if (result.isValid && result.level < minLevel) {
        results.set(wallet, {
          ...result,
          isValid: false,
          failureReason: `Insufficient KYC level`,
        });
      }
    }

    return results;
  }
}

/**
 * Attestation events for monitoring
 */
export enum AttestationEventType {
  Created = 'created',
  Updated = 'updated',
  Suspended = 'suspended',
  Revoked = 'revoked',
  Reactivated = 'reactivated',
  Expired = 'expired',
  Renewed = 'renewed',
}

/**
 * Attestation event
 */
export interface AttestationEvent {
  type: AttestationEventType;
  wallet: PublicKey;
  provider: PublicKey;
  attestation: PublicKey;
  timestamp: number;
  data?: Record<string, unknown>;
}

/**
 * Attestation event listener
 */
export class AttestationEventListener {
  private connection: Connection;
  private programId: PublicKey;
  private listeners: Map<string, (event: AttestationEvent) => void> = new Map();

  constructor(connection: Connection, programId: PublicKey) {
    this.connection = connection;
    this.programId = programId;
  }

  /**
   * Subscribe to attestation events
   */
  subscribe(
    eventType: AttestationEventType,
    callback: (event: AttestationEvent) => void
  ): void {
    const key = eventType.toString();
    this.listeners.set(key, callback);

    console.log(`[AttestationListener] Subscribed to ${eventType}`);
  }

  /**
   * Unsubscribe from events
   */
  unsubscribe(eventType: AttestationEventType): void {
    const key = eventType.toString();
    this.listeners.delete(key);

    console.log(`[AttestationListener] Unsubscribed from ${eventType}`);
  }

  /**
   * Emit event to listeners
   */
  private emit(event: AttestationEvent): void {
    const listener = this.listeners.get(event.type.toString());
    if (listener) {
      listener(event);
    }
  }
}

/**
 * Attestation validation errors
 */
export enum AttestationError {
  NotFound = 'ATTESTATION_NOT_FOUND',
  Expired = 'ATTESTATION_EXPIRED',
  Revoked = 'ATTESTATION_REVOKED',
  Suspended = 'ATTESTATION_SUSPENDED',
  InsufficientLevel = 'INSUFFICIENT_KYC_LEVEL',
  InvalidProvider = 'INVALID_PROVIDER',
  Unauthorized = 'UNAUTHORIZED',
}

/**
 * Helper to check if error indicates invalid attestation
 */
export function isAttestationInvalid(error: string): boolean {
  return Object.values(AttestationError).includes(error as AttestationError);
}

/**
 * Get human-readable status
 */
export function getStatusLabel(status: AttestationStatus): string {
  return AttestationStatus[status] || 'Unknown';
}

/**
 * Get human-readable KYC level
 */
export function getLevelLabel(level: KycLevel): string {
  switch (level) {
    case KycLevel.None:
      return 'None';
    case KycLevel.Basic:
      return 'Basic (Email/Phone)';
    case KycLevel.Standard:
      return 'Standard (ID Verified)';
    case KycLevel.Enhanced:
      return 'Enhanced (Full Due Diligence)';
    default:
      return 'Unknown';
  }
}

/**
 * Create default attestation manager
 */
export function createAttestationManager(
  connection: Connection,
  programId?: string
): AttestationStateManager {
  const pid = programId
    ? new PublicKey(programId)
    : new PublicKey('KYCAttestation11111111111111111111111111');

  return new AttestationStateManager(connection, pid);
}
