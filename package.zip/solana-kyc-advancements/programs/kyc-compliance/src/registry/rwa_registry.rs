//! Compliance Registry for RWA Issuance
//!
//! This module implements the primary registry designed specifically for managing
//! Real-World Assets (RWAs) with institutional-grade compliance standards.
//!
//! ## Overview
//!
//! The Compliance Registry for RWA Issuance provides:
//! - Asset class-specific compliance rules
//! - Investor accreditation tracking
//! - Transfer restriction enforcement
//! - Dividend/distribution management
//! - Corporate action handling
//!
//! ## Supported Asset Types
//!
//! - Securities (equity, debt)
//! - Real estate tokens
//! - Commodities
//! - Derivatives
//! - Fund shares
//!
//! ## Usage
//!
//! ```rust
//! use kyc_compliance::registry::rwa_registry::{RwaRegistry, RwaAsset, ComplianceRequirements};
//!
//! let registry = RwaRegistry::new(authority)?;
//! let asset = registry.register_asset(config)?;
//! ```

use solana_program::{
    account_info::AccountInfo,
    clock::Clock,
    entrypoint::ProgramResult,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::Sysvar,
};
use std::collections::HashMap;

/// Maximum asset name length
pub const MAX_ASSET_NAME_LENGTH: usize = 64;

/// Maximum description length
pub const MAX_DESCRIPTION_LENGTH: usize = 512;

/// Maximum allowed investors
pub const MAX_INVESTORS: usize = 10000;

/// Asset types supported
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum RwaAssetType {
    /// Equity security
    Equity = 0,
    /// Debt security
    Debt = 1,
    /// Real estate
    RealEstate = 2,
    /// Commodity
    Commodity = 3,
    /// Derivative
    Derivative = 4,
    /// Fund share
    FundShare = 5,
    /// Utility token
    UtilityToken = 6,
    /// Stablecoin
    Stablecoin = 7,
}

impl RwaAssetType {
    /// Get asset type name
    pub fn to_string(&self) -> &'static str {
        match self {
            RwaAssetType::Equity => "Equity",
            RwaAssetType::Debt => "Debt",
            RwaAssetType::RealEstate => "Real Estate",
            RwaAssetType::Commodity => "Commodity",
            RwaAssetType::Derivative => "Derivative",
            RwaAssetType::FundShare => "Fund Share",
            RwaAssetType::UtilityToken => "Utility Token",
            RwaAssetType::Stablecoin => "Stablecoin",
        }
    }

    /// Check if requires accreditation
    pub fn requires_accreditation(&self) -> bool {
        matches!(
            self,
            RwaAssetType::Equity
                | RwaAssetType::Debt
                | RwaAssetType::FundShare
                | RwaAssetType::RealEstate
        )
    }

    /// Check if requires KYC
    pub fn requires_kyc(&self) -> bool {
        true // All RWA types require KYC
    }
}

/// Investor accreditation level
#[derive(Debug, Clone, Copy, PartialEq, Eq, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum AccreditationLevel {
    /// No accreditation
    None = 0,
    /// Retail investor
    Retail = 1,
    /// Accredited investor
    Accredited = 2,
    /// Qualified purchaser
    QualifiedPurchaser = 3,
    /// Institutional investor
    Institutional = 4,
}

impl AccreditationLevel {
    /// Get level rank (higher = more restrictions)
    pub fn rank(&self) -> u8 {
        match self {
            AccreditationLevel::None => 0,
            AccreditationLevel::Retail => 1,
            AccreditationLevel::Accredited => 2,
            AccreditationLevel::QualifiedPurchaser => 3,
            AccreditationLevel::Institutional => 4,
        }
    }

    /// Get level name
    pub fn to_string(&self) -> &'static str {
        match self {
            AccreditationLevel::None => "None",
            AccreditationLevel::Retail => "Retail",
            AccreditationLevel::Accredited => "Accredited",
            AccreditationLevel::QualifiedPurchaser => "Qualified Purchaser",
            AccreditationLevel::Institutional => "Institutional",
        }
    }

    /// Check if can invest in asset requiring given level
    pub fn can_invest(&self, required: AccreditationLevel) -> bool {
        self.rank() >= required.rank()
    }
}

/// Geographic restriction
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct GeographicRestriction {
    /// Country codes (ISO 3166-1 alpha-2)
    pub allowed_countries: Vec<String>,
    /// Blocked countries
    pub blocked_countries: Vec<String>,
    /// Whether to allow list is exclusive
    pub allow_list_exclusive: bool,
}

impl GeographicRestriction {
    /// Create new restriction
    pub fn new(allowed: Vec<String>, blocked: Vec<String>) -> Self {
        Self {
            allowed_countries: allowed,
            blocked_countries: blocked,
            allow_list_exclusive: !allowed.is_empty(),
        }
    }

    /// Check if country is allowed
    pub fn is_allowed(&self, country_code: &str) -> bool {
        let country = country_code.to_uppercase();

        if self.allow_list_exclusive {
            self.allowed_countries.iter().any(|c| c.to_uppercase() == country)
        } else {
            !self.blocked_countries.iter().any(|c| c.to_uppercase() == country)
        }
    }

    /// Allow all countries
    pub fn allow_all() -> Self {
        Self {
            allowed_countries: Vec::new(),
            blocked_countries: Vec::new(),
            allow_list_exclusive: false,
        }
    }

    /// Block specific countries
    pub fn block_countries(countries: Vec<String>) -> Self {
        Self {
            allowed_countries: Vec::new(),
            blocked_countries: countries,
            allow_list_exclusive: false,
        }
    }
}

/// Investment limits
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct InvestmentLimits {
    /// Minimum investment amount (in lamports)
    pub min_investment: u64,
    /// Maximum investment amount (in lamports)
    pub max_investment: u64,
    /// Maximum total holdings (in lamports)
    pub max_holdings: u64,
    /// Maximum number of investors
    pub max_investors: u32,
}

impl Default for InvestmentLimits {
    fn default() -> Self {
        Self {
            min_investment: 0,
            max_investment: u64::MAX,
            max_holdings: u64::MAX,
            max_investors: MAX_INVESTORS as u32,
        }
    }
}

/// Compliance requirements for an asset
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct ComplianceRequirements {
    /// Required KYC level
    pub required_kyc_level: u8,
    /// Required accreditation level
    pub required_accreditation: AccreditationLevel,
    /// Geographic restrictions
    pub geographic_restriction: GeographicRestriction,
    /// Investment limits
    pub investment_limits: InvestmentLimits,
    /// Whether to restrict to verified wallets only
    pub verified_wallets_only: bool,
    /// Whether to enable transfer restrictions
    pub transfer_restrictions: bool,
    /// Whether to require manual approval for transfers
    pub manual_transfer_approval: bool,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl Default for ComplianceRequirements {
    fn default() -> Self {
        Self {
            required_kyc_level: 2, // Standard
            required_accreditation: AccreditationLevel::Retail,
            geographic_restriction: GeographicRestriction::allow_all(),
            investment_limits: InvestmentLimits::default(),
            verified_wallets_only: true,
            transfer_restrictions: true,
            manual_transfer_approval: false,
            reserved: [0u8; 64],
        }
    }
}

impl ComplianceRequirements {
    /// Create requirements for publicly traded security
    pub fn public_security() -> Self {
        Self {
            required_kyc_level: 1,
            required_accreditation: AccreditationLevel::Retail,
            geographic_restriction: GeographicRestriction::allow_all(),
            investment_limits: InvestmentLimits::default(),
            verified_wallets_only: true,
            transfer_restrictions: false,
            manual_transfer_approval: false,
            reserved: [0u8; 64],
        }
    }

    /// Create requirements for private security
    pub fn private_security() -> Self {
        Self {
            required_kyc_level: 2,
            required_accreditation: AccreditationLevel::Accredited,
            geographic_restriction: GeographicRestriction::allow_all(),
            investment_limits: InvestmentLimits {
                min_investment: 10000 * 1_000_000, // 10k USD equivalent
                max_investment: u64::MAX,
                max_holdings: u64::MAX,
                max_investors: 2000,
            },
            verified_wallets_only: true,
            transfer_restrictions: true,
            manual_transfer_approval: true,
            reserved: [0u8; 64],
        }
    }

    /// Create requirements for real estate
    pub fn real_estate() -> Self {
        Self {
            required_kyc_level: 2,
            required_accreditation: AccreditationLevel::Accredited,
            geographic_restriction: GeographicRestriction::allow_all(),
            investment_limits: InvestmentLimits {
                min_investment: 50000 * 1_000_000, // 50k USD equivalent
                max_investment: u64::MAX,
                max_holdings: u64::MAX,
                max_investors: 1000,
            },
            verified_wallets_only: true,
            transfer_restrictions: true,
            manual_transfer_approval: true,
            reserved: [0u8; 64],
        }
    }

    /// Check if investor can invest
    pub fn can_invest(
        &self,
        kyc_level: u8,
        accreditation: AccreditationLevel,
        country: &str,
        investment_amount: u64,
    ) -> Result<(), ProgramError> {
        // Check KYC level
        if kyc_level < self.required_kyc_level {
            return Err(ProgramError::Custom(0x7001)); // InsufficientKyc
        }

        // Check accreditation
        if !accreditation.can_invest(self.required_accreditation) {
            return Err(ProgramError::Custom(0x7002)); // InsufficientAccreditation
        }

        // Check geographic restriction
        if !self.geographic_restriction.is_allowed(country) {
            return Err(ProgramError::Custom(0x7003)); // GeographicRestriction
        }

        // Check investment limits
        if investment_amount < self.investment_limits.min_investment {
            return Err(ProgramError::Custom(0x7004)); // BelowMinimum
        }

        if investment_amount > self.investment_limits.max_investment {
            return Err(ProgramError::Custom(0x7005)); // AboveMaximum
        }

        Ok(())
    }
}

/// RWA asset information
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct RwaAsset {
    /// Asset public key
    pub asset_id: Pubkey,
    /// Asset name
    pub name: String,
    /// Asset symbol
    pub symbol: String,
    /// Asset type
    pub asset_type: RwaAssetType,
    /// Issuer public key
    pub issuer: Pubkey,
    /// Total supply
    pub total_supply: u64,
    /// Mint address
    pub mint: Pubkey,
    /// Compliance requirements
    pub compliance: ComplianceRequirements,
    /// Metadata URI
    pub metadata_uri: String,
    /// Whether active
    pub is_active: bool,
    /// Creation timestamp
    pub created_at: i64,
    /// Last update timestamp
    pub updated_at: i64,
    /// Version
    pub version: u8,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl RwaAsset {
    /// Create new RWA asset
    pub fn new(
        asset_id: Pubkey,
        name: String,
        symbol: String,
        asset_type: RwaAssetType,
        issuer: Pubkey,
        total_supply: u64,
        mint: Pubkey,
        compliance: ComplianceRequirements,
    ) -> Self {
        let now = Clock::default().unix_timestamp;

        Self {
            asset_id,
            name,
            symbol,
            asset_type,
            issuer,
            total_supply,
            mint,
            compliance,
            metadata_uri: String::new(),
            is_active: true,
            created_at: now,
            updated_at: now,
            version: 1,
            reserved: [0u8; 64],
        }
    }

    /// Check if transfers are allowed
    pub fn transfers_allowed(&self) -> bool {
        self.is_active && self.compliance.transfer_restrictions
    }

    /// Check if manual approval required
    pub fn requires_manual_approval(&self) -> bool {
        self.compliance.manual_transfer_approval
    }
}

/// Investor record
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct InvestorRecord {
    /// Investor wallet
    pub wallet: Pubkey,
    /// Accreditation level
    pub accreditation: AccreditationLevel,
    /// Country code
    pub country: String,
    /// Total holdings (in mint units)
    pub holdings: u64,
    /// Total invested amount
    pub invested_amount: u64,
    /// Whether verified
    pub is_verified: bool,
    /// KYC level
    pub kyc_level: u8,
    /// Registration timestamp
    pub registered_at: i64,
    /// Last update timestamp
    pub updated_at: i64,
}

impl InvestorRecord {
    /// Create new investor record
    pub fn new(
        wallet: Pubkey,
        accreditation: AccreditationLevel,
        country: String,
        kyc_level: u8,
    ) -> Self {
        let now = Clock::default().unix_timestamp;

        Self {
            wallet,
            accreditation,
            country,
            holdings: 0,
            invested_amount: 0,
            is_verified: true,
            kyc_level,
            registered_at: now,
            updated_at: now,
        }
    }

    /// Check if investor can participate
    pub fn can_participate(&self, requirements: &ComplianceRequirements) -> bool {
        self.is_verified &&
        self.accreditation.can_invest(requirements.required_accreditation) &&
        requirements.geographic_restriction.is_allowed(&self.country) &&
        self.kyc_level >= requirements.required_kyc_level
    }

    /// Update holdings
    pub fn update_holdings(&mut self, amount: u64, is_addition: bool) {
        if is_addition {
            self.holdings = self.holdings.saturating_add(amount);
        } else {
            self.holdings = self.holdings.saturating_sub(amount);
        }
        self.updated_at = Clock::default().unix_timestamp;
    }
}

/// Transfer approval request
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct TransferApproval {
    /// Request ID
    pub request_id: Pubkey,
    /// Asset
    pub asset: Pubkey,
    /// From wallet
    pub from: Pubkey,
    /// To wallet
    pub to: Pubkey,
    /// Amount
    pub amount: u64,
    /// Status
    pub status: TransferStatus,
    /// Approver
    pub approver: Option<Pubkey>,
    /// Reason if rejected
    pub rejection_reason: Option<String>,
    /// Request timestamp
    pub requested_at: i64,
    /// Resolved timestamp
    pub resolved_at: Option<i64>,
}

impl TransferApproval {
    /// Create new request
    pub fn new(
        request_id: Pubkey,
        asset: Pubkey,
        from: Pubkey,
        to: Pubkey,
        amount: u64,
    ) -> Self {
        Self {
            request_id,
            asset,
            from,
            to,
            amount,
            status: TransferStatus::Pending,
            approver: None,
            rejection_reason: None,
            requested_at: Clock::default().unix_timestamp,
            resolved_at: None,
        }
    }

    /// Approve transfer
    pub fn approve(&mut self, approver: Pubkey) {
        self.status = TransferStatus::Approved;
        self.approver = Some(approver);
        self.resolved_at = Some(Clock::default().unix_timestamp);
    }

    /// Reject transfer
    pub fn reject(&mut self, reason: String) {
        self.status = TransferStatus::Rejected;
        self.rejection_reason = Some(reason);
        self.resolved_at = Some(Clock::default().unix_timestamp);
    }
}

/// Transfer status
#[derive(Debug, Clone, Copy, PartialEq, Eq, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum TransferStatus {
    /// Pending approval
    Pending = 0,
    /// Approved
    Approved = 1,
    /// Rejected
    Rejected = 2,
    /// Cancelled
    Cancelled = 3,
    /// Expired
    Expired = 4,
}

/// RWA Registry errors
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RegistryError {
    /// Asset not found
    AssetNotFound = 0x7001,
    /// Investor not found
    InvestorNotFound = 0x7002,
    /// Insufficient KYC
    InsufficientKyc = 0x7003,
    /// Insufficient accreditation
    InsufficientAccreditation = 0x7004,
    /// Geographic restriction
    GeographicRestriction = 0x7005,
    /// Below minimum investment
    BelowMinimum = 0x7006,
    /// Above maximum investment
    AboveMaximum = 0x7007,
    /// Transfer not approved
    TransferNotApproved = 0x7008,
    /// Max investors reached
    MaxInvestorsReached = 0x7009,
    /// Unauthorized
    Unauthorized = 0x700a,
    /// Invalid asset type
    InvalidAssetType = 0x700b,
}

impl From<RegistryError> for ProgramError {
    fn from(e: RegistryError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

/// RWA Registry implementation
pub struct RwaRegistry;

impl RwaRegistry {
    /// Register new RWA asset
    pub fn register_asset(
        asset: RwaAsset,
    ) -> Result<RwaAsset, ProgramError> {
        // Validate inputs
        if asset.name.is_empty() || asset.name.len() > MAX_ASSET_NAME_LENGTH {
            return Err(ProgramError::Custom(0x7010)); // InvalidName
        }

        // Validate asset type
        if !matches!(
            asset.asset_type,
            RwaAssetType::Equity
                | RwaAssetType::Debt
                | RwaAssetType::RealEstate
                | RwaAssetType::Commodity
                | RwaAssetType::Derivative
                | RwaAssetType::FundShare
                | RwaAssetType::UtilityToken
                | RwaAssetType::Stablecoin
        ) {
            return Err(RegistryError::InvalidAssetType.into());
        }

        Ok(asset)
    }

    /// Verify investor eligibility
    pub fn verify_investor(
        investor: &InvestorRecord,
        asset: &RwaAsset,
        amount: u64,
    ) -> Result<(), ProgramError> {
        // Check if investor can participate
        if !investor.can_participate(&asset.compliance) {
            return Err(RegistryError::InsufficientAccreditation.into());
        }

        // Check investment limits
        asset.compliance.investment_limits.can_invest(
            investor.kyc_level,
            investor.accreditation,
            &investor.country,
            amount,
        )
    }

    /// Process transfer
    pub fn process_transfer(
        from: &InvestorRecord,
        to: &InvestorRecord,
        asset: &RwaAsset,
        amount: u64,
    ) -> Result<(), ProgramError> {
        // Check if transfers are allowed
        if !asset.transfers_allowed() {
            return Err(ProgramError::Custom(0x7011)); // TransfersDisabled
        }

        // Verify both parties are eligible
        Self::verify_investor(to, asset, amount)?;

        // Check from has sufficient holdings
        if from.holdings < amount {
            return Err(ProgramError::Custom(0x7012)); // InsufficientHoldings
        }

        Ok(())
    }

    /// Create transfer approval request
    pub fn create_transfer_approval(
        asset: &RwaAsset,
        from: &InvestorRecord,
        to: &InvestorRecord,
        amount: u64,
    ) -> Result<TransferApproval, ProgramError> {
        // Check if approval required
        if !asset.requires_manual_approval() {
            return Err(ProgramError::Custom(0x7013)); // ApprovalNotRequired
        }

        // Verify transfer is valid
        Self::process_transfer(from, to, asset, amount)?;

        // Create request
        Ok(TransferApproval::new(
            Pubkey::default(), // Would generate proper ID
            asset.asset_id,
            from.wallet,
            to.wallet,
            amount,
        ))
    }

    /// Update asset compliance requirements
    pub fn update_compliance(
        asset: &mut RwaAsset,
        new_requirements: ComplianceRequirements,
    ) -> Result<(), ProgramError> {
        // Update compliance
        asset.compliance = new_requirements;
        asset.updated_at = Clock::default().unix_timestamp;

        Ok(())
    }

    /// Calculate investor cap
    pub fn calculate_investor_cap(
        investor: &InvestorRecord,
        asset: &RwaAsset,
    ) -> u64 {
        let limits = &asset.compliance.investment_limits;

        // Start with max investment
        let mut cap = limits.max_investment;

        // Subtract current holdings
        if cap > investor.holdings {
            cap = cap.saturating_sub(investor.holdings);
        } else {
            cap = 0;
        }

        // Ensure within max holdings
        if limits.max_holdings > investor.holdings {
            let remaining = limits.max_holdings.saturating_sub(investor.holdings);
            cap = cap.min(remaining);
        }

        cap
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_geographic_restriction_allow_list() {
        let restriction = GeographicRestriction::new(
            vec!["US".to_string(), "GB".to_string()],
            vec![],
        );

        assert!(restriction.is_allowed("US"));
        assert!(restriction.is_allowed("GB"));
        assert!(!restriction.is_allowed("CN"));
    }

    #[test]
    fn test_geographic_restriction_block_list() {
        let restriction = GeographicRestriction::block_countries(
            vec!["KP".to_string(), "IR".to_string()],
        );

        assert!(!restriction.is_allowed("KP"));
        assert!(!restriction.is_allowed("IR"));
        assert!(restriction.is_allowed("US"));
    }

    #[test]
    fn test_accreditation_levels() {
        assert!(AccreditationLevel::Institutional.can_invest(AccreditationLevel::Retail));
        assert!(AccreditationLevel::Accredited.can_invest(AccreditationLevel::Retail));
        assert!(!AccreditationLevel::Retail.can_invest(AccreditationLevel::Accredited));
    }

    #[test]
    fn test_compliance_requirements_public_security() {
        let req = ComplianceRequirements::public_security();

        assert_eq!(req.required_kyc_level, 1);
        assert_eq!(req.required_accreditation, AccreditationLevel::Retail);
        assert!(!req.transfer_restrictions);
    }

    #[test]
    fn test_compliance_requirements_private_security() {
        let req = ComplianceRequirements::private_security();

        assert_eq!(req.required_kyc_level, 2);
        assert_eq!(req.required_accreditation, AccreditationLevel::Accredited);
        assert!(req.transfer_restrictions);
        assert!(req.manual_transfer_approval);
    }

    #[test]
    fn test_investor_can_participate() {
        let investor = InvestorRecord::new(
            Pubkey::new_from_array([1u8; 32]),
            AccreditationLevel::Accredited,
            "US".to_string(),
            2,
        );

        let requirements = ComplianceRequirements::private_security();

        assert!(investor.can_participate(&requirements));
    }

    #[test]
    fn test_rwa_asset_creation() {
        let asset = RwaAsset::new(
            Pubkey::new_from_array([1u8; 32]),
            "Test Asset".to_string(),
            "TEST".to_string(),
            RwaAssetType::Equity,
            Pubkey::new_from_array([2u8; 32]),
            1000000,
            Pubkey::new_from_array([3u8; 32]),
            ComplianceRequirements::default(),
        );

        assert_eq!(asset.name, "Test Asset");
        assert!(asset.is_active);
    }

    #[test]
    fn test_transfer_approval() {
        let approval = TransferApproval::new(
            Pubkey::new_from_array([1u8; 32]),
            Pubkey::new_from_array([2u8; 32]),
            Pubkey::new_from_array([3u8; 32]),
            Pubkey::new_from_array([4u8; 32]),
            1000,
        );

        assert_eq!(approval.status, TransferStatus::Pending);

        approval.approve(Pubkey::new_from_array([5u8; 32]));
        assert_eq!(approval.status, TransferStatus::Approved);
    }
}
