//! Administrative Access Control Module
//!
//! This module provides dedicated functionality for strictly controlling administrative
//! access to sensitive registry and program settings. It implements role-based access
//! control (RBAC) principles for all administrative functions within the SDK.
//!
//! ## Overview
//!
//! The Admin-Only module provides:
//! - Role-based permission management
//! - Time-bound administrative access
//! - Audit logging for all admin actions
//! - Multi-signature support for critical operations
//! - Delegation capabilities for temporary access
//!
//! ## Security Principles
//!
//! - Principle of least privilege: Admin accounts only get minimum required permissions
//! - Separation of duties: Critical operations require multiple approvers
//! - Audit trail: All admin actions are logged
//! - Time-limited access: Temporary elevation of privileges
//!
//! ## Usage
//!
//! ```rust
//! use kyc_compliance::security::admin::{AdminControl, AdminRole, AdminPermission};
//!
//! // Check if account has permission
//! let has_permission = AdminControl::check_permission(&admin, AdminPermission::UpdateConfig);
//!
//! // Require admin access
//! AdminControl::require_admin(ctx, AdminPermission::MintTokens)?;
//! ```

use solana_program::{
    account_info::AccountInfo,
    clock::Clock,
    entrypoint::ProgramResult,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::Sysvar,
};
use std::collections::HashMap;

/// Maximum number of admin roles
pub const MAX_ADMIN_ROLES: usize = 16;

/// Maximum number of permissions per role
pub const MAX_PERMISSIONS_PER_ROLE: usize = 32;

/// Maximum number of delegated admins
pub const MAX_DELEGATES: usize = 10;

/// Maximum role name length
pub const MAX_ROLE_NAME_LENGTH: usize = 32;

/// Administrative permission types
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum AdminPermission {
    /// No specific permission
    None = 0,
    /// Update program configuration
    UpdateConfig = 1,
    /// Manage KYC providers
    ManageProviders = 2,
    /// Mint tokens
    MintTokens = 3,
    /// Burn tokens
    BurnTokens = 4,
    /// Update compliance rules
    UpdateRules = 5,
    /// Freeze accounts
    FreezeAccounts = 6,
    /// Unfreeze accounts
    UnfreezeAccounts = 7,
    /// Manage registry
    ManageRegistry = 8,
    /// Update risk thresholds
    UpdateRiskThresholds = 9,
    /// Manage circuit breaker
    ManageCircuitBreaker = 10,
    /// Add or remove admins
    ManageAdmins = 11,
    /// View sensitive data
    ViewSensitiveData = 12,
    /// Emergency operations
    Emergency = 13,
    /// Update fee structure
    UpdateFees = 14,
    /// Manage whitelists
    ManageWhitelist = 15,
}

impl AdminPermission {
    /// Get all available permissions
    pub fn all() -> Vec<AdminPermission> {
        vec![
            AdminPermission::UpdateConfig,
            AdminPermission::ManageProviders,
            AdminPermission::MintTokens,
            AdminPermission::BurnTokens,
            AdminPermission::UpdateRules,
            AdminPermission::FreezeAccounts,
            AdminPermission::UnfreezeAccounts,
            AdminPermission::ManageRegistry,
            AdminPermission::UpdateRiskThresholds,
            AdminPermission::ManageCircuitBreaker,
            AdminPermission::ManageAdmins,
            AdminPermission::ViewSensitiveData,
            AdminPermission::Emergency,
            AdminPermission::UpdateFees,
            AdminPermission::ManageWhitelist,
        ]
    }

    /// Check if this is a critical permission
    pub fn is_critical(&self) -> bool {
        matches!(
            self,
            AdminPermission::ManageAdmins
                | AdminPermission::Emergency
                | AdminPermission::ManageCircuitBreaker
        )
    }

    /// Get permission name
    pub fn to_string(&self) -> &'static str {
        match self {
            AdminPermission::None => "None",
            AdminPermission::UpdateConfig => "Update Configuration",
            AdminPermission::ManageProviders => "Manage KYC Providers",
            AdminPermission::MintTokens => "Mint Tokens",
            AdminPermission::BurnTokens => "Burn Tokens",
            AdminPermission::UpdateRules => "Update Compliance Rules",
            AdminPermission::FreezeAccounts => "Freeze Accounts",
            AdminPermission::UnfreezeAccounts => "Unfreeze Accounts",
            AdminPermission::ManageRegistry => "Manage Registry",
            AdminPermission::UpdateRiskThresholds => "Update Risk Thresholds",
            AdminPermission::ManageCircuitBreaker => "Manage Circuit Breaker",
            AdminPermission::ManageAdmins => "Manage Administrators",
            AdminPermission::ViewSensitiveData => "View Sensitive Data",
            AdminPermission::Emergency => "Emergency Operations",
            AdminPermission::UpdateFees => "Update Fee Structure",
            AdminPermission::ManageWhitelist => "Manage Whitelist",
        }
    }
}

/// Predefined admin role types
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum AdminRole {
    /// Super administrator with all permissions
    SuperAdmin = 0,
    /// Compliance officer
    ComplianceOfficer = 1,
    /// Operations manager
    OperationsManager = 2,
    /// Auditor (read-only sensitive data)
    Auditor = 3,
    /// Emergency responder
    EmergencyResponder = 4,
    /// Risk manager
    RiskManager = 5,
    /// Custom role
    Custom = 99,
}

impl AdminRole {
    /// Get default permissions for role
    pub fn default_permissions(&self) -> Vec<AdminPermission> {
        match self {
            AdminRole::SuperAdmin => AdminPermission::all(),
            AdminRole::ComplianceOfficer => vec![
                AdminPermission::ManageProviders,
                AdminPermission::UpdateRules,
                AdminPermission::ViewSensitiveData,
            ],
            AdminRole::OperationsManager => vec![
                AdminPermission::MintTokens,
                AdminPermission::BurnTokens,
                AdminPermission::ManageRegistry,
                AdminPermission::ManageWhitelist,
            ],
            AdminRole::Auditor => vec![
                AdminPermission::ViewSensitiveData,
            ],
            AdminRole::EmergencyResponder => vec![
                AdminPermission::FreezeAccounts,
                AdminPermission::UnfreezeAccounts,
                AdminPermission::Emergency,
            ],
            AdminRole::RiskManager => vec![
                AdminPermission::UpdateRiskThresholds,
                AdminPermission::ViewSensitiveData,
            ],
            AdminRole::Custom => vec![],
        }
    }

    /// Check if role can grant permissions
    pub fn can_grant(&self) -> bool {
        matches!(self, AdminRole::SuperAdmin)
    }

    /// Check if role can manage admins
    pub fn can_manage_admins(&self) -> bool {
        matches!(self, AdminRole::SuperAdmin)
    }
}

/// Delegated admin access
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct DelegatedAccess {
    /// Delegate public key
    pub delegate: Pubkey,
    /// Granted by
    pub granted_by: Pubkey,
    /// Permissions granted
    pub permissions: Vec<AdminPermission>,
    /// Start time (unix timestamp)
    pub start_time: i64,
    /// Expiration time (unix timestamp)
    pub expiration_time: i64,
    /// Whether still active
    pub is_active: bool,
}

impl DelegatedAccess {
    /// Check if delegate has specific permission
    pub fn has_permission(&self, permission: AdminPermission) -> bool {
        self.is_active && self.permissions.contains(&permission)
    }

    /// Check if delegation is valid at given time
    pub fn is_valid_at(&self, timestamp: i64) -> bool {
        self.is_active && timestamp >= self.start_time && timestamp < self.expiration_time
    }

    /// Create new delegated access
    pub fn new(
        delegate: Pubkey,
        granted_by: Pubkey,
        permissions: Vec<AdminPermission>,
        duration_secs: i64,
        clock: &Clock,
    ) -> Result<Self, ProgramError> {
        let current_time = clock.unix_timestamp;

        Ok(Self {
            delegate,
            granted_by,
            permissions,
            start_time: current_time,
            expiration_time: current_time.checked_add(duration_secs)
                .ok_or(ProgramError::Custom(0x3001))?,
            is_active: true,
        })
    }

    /// Revoke delegation
    pub fn revoke(&mut self) {
        self.is_active = false;
    }
}

/// Admin account information
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct AdminAccount {
    /// Admin public key
    pub pubkey: Pubkey,
    /// Assigned role
    pub role: AdminRole,
    /// Custom permissions (if custom role)
    pub custom_permissions: Vec<AdminPermission>,
    /// Whether account is active
    pub is_active: bool,
    /// Created at timestamp
    pub created_at: i64,
    /// Last activity timestamp
    pub last_activity: i64,
    /// Number of operations performed
    pub operation_count: u64,
    /// Reserved space
    pub reserved: [u8; 32],
}

impl AdminAccount {
    /// Create new admin account
    pub fn new(pubkey: Pubkey, role: AdminRole) -> Self {
        let now = Clock::default().unix_timestamp;
        Self {
            pubkey,
            role,
            custom_permissions: Vec::new(),
            is_active: true,
            created_at: now,
            last_activity: now,
            operation_count: 0,
            reserved: [0u8; 32],
        }
    }

    /// Create with custom permissions
    pub fn with_custom_permissions(pubkey: Pubkey, permissions: Vec<AdminPermission>) -> Self {
        let mut account = Self::new(pubkey, AdminRole::Custom);
        account.custom_permissions = permissions;
        account
    }

    /// Check if admin has specific permission
    pub fn has_permission(&self, permission: AdminPermission) -> bool {
        if !self.is_active {
            return false;
        }

        if self.role == AdminRole::SuperAdmin {
            return true;
        }

        // Check role default permissions
        if self.role.default_permissions().contains(&permission) {
            return true;
        }

        // Check custom permissions
        self.custom_permissions.contains(&permission)
    }

    /// Record operation
    pub fn record_operation(&mut self) {
        self.operation_count = self.operation_count.saturating_add(1);
        self.last_activity = Clock::default().unix_timestamp;
    }

    /// Deactivate admin account
    pub fn deactivate(&mut self) {
        self.is_active = false;
    }

    /// Reactivate admin account
    pub fn reactivate(&mut self) {
        self.is_active = true;
    }
}

/// Admin configuration
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct AdminConfig {
    /// Root admin (cannot be removed)
    pub root_admin: Pubkey,
    /// List of admin accounts
    pub admins: Vec<Pubkey>,
    /// Admin roles mapping
    pub roles: HashMap<Pubkey, AdminRole>,
    /// Delegated access
    pub delegates: Vec<DelegatedAccess>,
    /// Whether multi-sig is required for critical operations
    pub require_multisig_critical: bool,
    /// Minimum signers for critical operations
    pub min_critical_signers: u8,
    /// Global pause (stops all admin operations)
    pub global_pause: bool,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl AdminConfig {
    /// Create new admin configuration
    pub fn new(root_admin: Pubkey) -> Self {
        Self {
            root_admin,
            admins: vec![root_admin],
            roles: HashMap::new(),
            delegates: Vec::new(),
            require_multisig_critical: true,
            min_critical_signers: 2,
            global_pause: false,
            reserved: [0u8; 64],
        }
    }

    /// Check if address is admin
    pub fn is_admin(&self, address: &Pubkey) -> bool {
        self.admins.contains(address)
    }

    /// Check if address is root admin
    pub fn is_root_admin(&self, address: &Pubkey) -> bool {
        *address == self.root_admin
    }

    /// Get role for address
    pub fn get_role(&self, address: &Pubkey) -> Option<AdminRole> {
        self.roles.get(address).copied()
    }

    /// Add admin
    pub fn add_admin(&mut self, new_admin: Pubkey, role: AdminRole) -> Result<(), ProgramError> {
        if self.admins.contains(&new_admin) {
            return Err(ProgramError::Custom(0x3002)); // AdminAlreadyExists
        }

        if self.admins.len() >= MAX_ADMIN_ROLES {
            return Err(ProgramError::Custom(0x3003)); // TooManyAdmins
        }

        self.admins.push(new_admin);
        self.roles.insert(new_admin, role);

        Ok(())
    }

    /// Remove admin (cannot remove root admin)
    pub fn remove_admin(&mut self, admin_to_remove: Pubkey) -> Result<(), ProgramError> {
        if self.is_root_admin(&admin_to_remove) {
            return Err(ProgramError::Custom(0x3004)); // CannotRemoveRootAdmin
        }

        self.admins.retain(|a| a != &admin_to_remove);
        self.roles.remove(&admin_to_remove);

        // Remove any delegations
        self.delegates.retain(|d| d.delegate != admin_to_remove);

        Ok(())
    }

    /// Add delegate
    pub fn add_delegate(&mut self, delegate: DelegatedAccess) -> Result<(), ProgramError> {
        if self.delegates.len() >= MAX_DELEGATES {
            return Err(ProgramError::Custom(0x3005)); // TooManyDelegates
        }

        self.delegates.push(delegate);
        Ok(())
    }

    /// Check delegate permissions
    pub fn check_delegate_permission(&self, delegate: &Pubkey, permission: AdminPermission, time: i64) -> bool {
        self.delegates.iter().any(|d| {
            d.delegate == *delegate && d.has_permission(permission) && d.is_valid_at(time)
        })
    }

    /// Global pause
    pub fn pause(&mut self) {
        self.global_pause = true;
    }

    /// Global unpause
    pub fn unpause(&mut self) {
        self.global_pause = false;
    }
}

/// Admin operation types for logging
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum AdminOperation {
    /// Add admin
    AddAdmin { new_admin: Pubkey, role: AdminRole },
    /// Remove admin
    RemoveAdmin { removed_admin: Pubkey },
    /// Update role
    UpdateRole { admin: Pubkey, new_role: AdminRole },
    /// Grant permission
    GrantPermission { admin: Pubkey, permission: AdminPermission },
    /// Revoke permission
    RevokePermission { admin: Pubkey, permission: AdminPermission },
    /// Add delegate
    AddDelegate { delegate: Pubkey, permissions: Vec<AdminPermission> },
    /// Remove delegate
    RemoveDelegate { delegate: Pubkey },
    /// Update config
    UpdateConfig { config_key: String },
    /// Emergency pause
    EmergencyPause { reason: String },
    /// Resume from pause
    EmergencyResume { reason: String },
}

/// Admin action audit log entry
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct AdminAuditEntry {
    /// Operation type
    pub operation: AdminOperation,
    /// Admin who performed action
    pub admin: Pubkey,
    /// Timestamp
    pub timestamp: i64,
    /// Block height
    pub block_height: u64,
    /// Success
    pub success: bool,
    /// Error message if failed
    pub error_message: Option<String>,
}

impl AdminAuditEntry {
    /// Create new audit entry
    pub fn new(operation: AdminOperation, admin: Pubkey, success: bool) -> Self {
        let clock = Clock::default();
        Self {
            operation,
            admin,
            timestamp: clock.unix_timestamp,
            block_height: clock.slot,
            success,
            error_message: None,
        }
    }

    /// Create failed entry
    pub fn failed(operation: AdminOperation, admin: Pubkey, error: String) -> Self {
        let mut entry = Self::new(operation, admin, false);
        entry.error_message = Some(error);
        entry
    }
}

/// Admin control implementation
pub struct AdminControl;

impl AdminControl {
    /// Check if account has specific permission
    pub fn check_permission(
        config: &AdminConfig,
        account: &Pubkey,
        permission: AdminPermission,
    ) -> bool {
        // Check global pause
        if config.global_pause {
            return false;
        }

        // Check if admin
        if config.is_admin(account) {
            if let Some(role) = config.get_role(account) {
                let admin_account = AdminAccount::new(*account, role);
                return admin_account.has_permission(permission);
            }
        }

        // Check if delegate
        let clock = Clock::default();
        config.check_delegate_permission(account, permission, clock.unix_timestamp)
    }

    /// Require specific permission
    pub fn require_permission(
        config: &AdminConfig,
        account: &Pubkey,
        permission: AdminPermission,
    ) -> Result<(), ProgramError> {
        if !Self::check_permission(config, account, permission) {
            return Err(ProgramError::Custom(0x3006)); // UnauthorizedAdmin
        }
        Ok(())
    }

    /// Require admin access
    pub fn require_admin(
        config: &AdminConfig,
        account: &Pubkey,
    ) -> Result<(), ProgramError> {
        if !config.is_admin(account) {
            return Err(ProgramError::Custom(0x3006)); // UnauthorizedAdmin
        }

        if config.global_pause {
            return Err(ProgramError::Custom(0x3007)); // GlobalPauseActive
        }

        Ok(())
    }

    /// Require root admin
    pub fn require_root_admin(
        config: &AdminConfig,
        account: &Pubkey,
    ) -> Result<(), ProgramError> {
        if !config.is_root_admin(account) {
            return Err(ProgramError::Custom(0x3006)); // UnauthorizedAdmin
        }
        Ok(())
    }

    /// Require multiple signers for critical operation
    pub fn require_multisig(
        config: &AdminConfig,
        signers: &[Pubkey],
    ) -> Result<(), ProgramError> {
        if !config.require_multisig_critical {
            return Ok(());
        }

        let valid_signers: Vec<_> = signers.iter()
            .filter(|s| config.is_admin(s))
            .collect();

        if valid_signers.len() < config.min_critical_signers as usize {
            return Err(ProgramError::Custom(0x3008)); // InsufficientSigners
        }

        Ok(())
    }

    /// Require specific role
    pub fn require_role(
        config: &AdminConfig,
        account: &Pubkey,
        required_role: AdminRole,
    ) -> Result<(), ProgramError> {
        if let Some(role) = config.get_role(account) {
            if role == required_role || role == AdminRole::SuperAdmin {
                return Ok(());
            }
        }
        Err(ProgramError::Custom(0x3006)) // UnauthorizedAdmin
    }

    /// Add new admin (requires root admin)
    pub fn add_admin(
        config: &mut AdminConfig,
        caller: &Pubkey,
        new_admin: Pubkey,
        role: AdminRole,
    ) -> Result<AdminAuditEntry, ProgramError> {
        // Require root admin
        Self::require_root_admin(config, caller)?;

        // Cannot add root admin
        if role == AdminRole::SuperAdmin {
            return Err(ProgramError::Custom(0x3009)); // CannotAssignSuperAdmin
        }

        // Add admin
        config.add_admin(new_admin, role)?;

        Ok(AdminAuditEntry::new(
            AdminOperation::AddAdmin { new_admin, role },
            *caller,
            true,
        ))
    }

    /// Remove admin (requires root admin)
    pub fn remove_admin(
        config: &mut AdminConfig,
        caller: &Pubkey,
        admin_to_remove: Pubkey,
    ) -> Result<AdminAuditEntry, ProgramError> {
        Self::require_root_admin(config, caller)?;
        config.remove_admin(admin_to_remove)?;

        Ok(AdminAuditEntry::new(
            AdminOperation::RemoveAdmin { removed_admin: admin_to_remove },
            *caller,
            true,
        ))
    }

    /// Grant temporary delegate access
    pub fn grant_delegate(
        config: &mut AdminConfig,
        caller: &Pubkey,
        delegate: Pubkey,
        permissions: Vec<AdminPermission>,
        duration_secs: i64,
    ) -> Result<DelegatedAccess, ProgramError> {
        // Require admin with delegation permission
        Self::require_permission(config, caller, AdminPermission::ManageAdmins)?;

        let clock = Clock::default();
        let delegation = DelegatedAccess::new(delegate, *caller, permissions, duration_secs, &clock)?;
        config.add_delegate(delegation.clone())?;

        Ok(delegation)
    }

    /// Revoke delegate access
    pub fn revoke_delegate(
        config: &mut AdminConfig,
        caller: &Pubkey,
        delegate: Pubkey,
    ) -> Result<(), ProgramError> {
        Self::require_permission(config, caller, AdminPermission::ManageAdmins)?;

        if let Some(d) = config.delegates.iter_mut().find(|d| d.delegate == delegate) {
            d.revoke();
        }

        Ok(())
    }

    /// Emergency pause (any admin with emergency permission)
    pub fn emergency_pause(
        config: &mut AdminConfig,
        caller: &Pubkey,
        reason: String,
    ) -> Result<AdminAuditEntry, ProgramError> {
        Self::require_permission(config, caller, AdminPermission::Emergency)?;
        config.pause();

        Ok(AdminAuditEntry::new(
            AdminOperation::EmergencyPause { reason },
            *caller,
            true,
        ))
    }

    /// Emergency resume (requires root admin)
    pub fn emergency_resume(
        config: &mut AdminConfig,
        caller: &Pubkey,
        reason: String,
    ) -> Result<AdminAuditEntry, ProgramError> {
        Self::require_root_admin(config, caller)?;
        config.unpause();

        Ok(AdminAuditEntry::new(
            AdminOperation::EmergencyResume { reason },
            *caller,
            true,
        ))
    }
}

/// Errors for admin operations
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AdminError {
    /// Overflow in duration calculation
    DurationOverflow = 0x3001,
    /// Admin already exists
    AdminAlreadyExists = 0x3002,
    /// Too many admins
    TooManyAdmins = 0x3003,
    /// Cannot remove root admin
    CannotRemoveRootAdmin = 0x3004,
    /// Too many delegates
    TooManyDelegates = 0x3005,
    /// Unauthorized admin
    UnauthorizedAdmin = 0x3006,
    /// Global pause active
    GlobalPauseActive = 0x3007,
    /// Insufficient signers
    InsufficientSigners = 0x3008,
    /// Cannot assign super admin role
    CannotAssignSuperAdmin = 0x3009,
    /// Role not found
    RoleNotFound = 0x300a,
}

impl From<AdminError> for ProgramError {
    fn from(e: AdminError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn create_test_config() -> AdminConfig {
        let root = Pubkey::new_from_array([1u8; 32]);
        AdminConfig::new(root)
    }

    #[test]
    fn test_admin_config_creation() {
        let root = Pubkey::new_from_array([1u8; 32]);
        let config = AdminConfig::new(root);

        assert!(config.is_admin(&root));
        assert!(config.is_root_admin(&root));
    }

    #[test]
    fn test_add_admin() {
        let mut config = create_test_config();
        let new_admin = Pubkey::new_from_array([2u8; 32]);

        let result = config.add_admin(new_admin, AdminRole::ComplianceOfficer);
        assert!(result.is_ok());
        assert!(config.is_admin(&new_admin));
    }

    #[test]
    fn test_cannot_remove_root_admin() {
        let mut config = create_test_config();
        let root = config.root_admin;

        let result = config.remove_admin(root);
        assert!(result.is_err());
    }

    #[test]
    fn test_admin_permission_check() {
        let mut config = create_test_config();
        let admin = Pubkey::new_from_array([2u8; 32]);

        config.add_admin(admin, AdminRole::ComplianceOfficer).unwrap();

        assert!(AdminControl::check_permission(&config, &admin, AdminPermission::ManageProviders));
        assert!(!AdminControl::check_permission(&config, &admin, AdminPermission::MintTokens));
    }

    #[test]
    fn test_global_pause() {
        let mut config = create_test_config();
        let admin = Pubkey::new_from_array([2u8; 32]);

        config.add_admin(admin, AdminRole::SuperAdmin).unwrap();

        // Before pause
        assert!(AdminControl::check_permission(&config, &admin, AdminPermission::UpdateConfig));

        // After pause
        config.pause();
        assert!(!AdminControl::check_permission(&config, &admin, AdminPermission::UpdateConfig));
    }

    #[test]
    fn test_delegated_access() {
        let clock = Clock::default();
        let delegate = Pubkey::new_from_array([3u8; 32]);
        let granted_by = Pubkey::new_from_array([1u8; 32]);

        let permissions = vec![AdminPermission::ViewSensitiveData];
        let delegation = DelegatedAccess::new(
            delegate,
            granted_by,
            permissions,
            3600, // 1 hour
            &clock,
        ).unwrap();

        assert!(delegation.has_permission(AdminPermission::ViewSensitiveData));
        assert!(!delegation.has_permission(AdminPermission::MintTokens));
    }
}
