//! Risk Data Provider Aggregator Module
//!
//! This module implements a data layer that aggregates risk information from
//! multiple global intelligence providers to provide a single compliance verdict.
//!
//! ## Overview
//!
//! The aggregator:
//! - Interfaces with multiple risk data providers
//! - Normalizes data from different sources
//! - Applies weighted scoring algorithms
//! - Provides fallback mechanisms
//! - Maintains provider health metrics
//!
//! ## Supported Providers
//!
//! - Chainalysis
//! - Elliptic
//! - TRM Labs
//! - CipherTrace
//! - Custom internal providers
//!
//! ## Usage
//!
//! ```rust
//! use kyc_compliance::risk_engine::providers::aggregator::{RiskAggregator, ProviderConfig, AggregatedRiskReport};
//!
//! let aggregator = RiskAggregator::new(config, providers)?;
//! let report = aggregator.aggregate_risk(wallet).await?;
//! ```

use solana_program::{
    account_info::AccountInfo,
    clock::Clock,
    entrypoint::ProgramResult,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::Sysvar,
};
use std::collections::HashMap;

/// Maximum number of providers supported
pub const MAX_PROVIDERS: usize = 10;

/// Maximum provider response time in milliseconds
pub const MAX_RESPONSE_TIME_MS: u64 = 5000;

/// Default confidence threshold
pub const DEFAULT_CONFIDENCE_THRESHOLD: u8 = 60;

/// Provider types
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum ProviderType {
    /// Chainalysis
    Chainalysis = 0,
    /// Elliptic
    Elliptic = 1,
    /// TRM Labs
    TRMLabs = 2,
    /// CipherTrace
    CipherTrace = 3,
    /// Internal
    Internal = 99,
}

impl ProviderType {
    /// Get provider name
    pub fn to_string(&self) -> &'static str {
        match self {
            ProviderType::Chainalysis => "Chainalysis",
            ProviderType::Elliptic => "Elliptic",
            ProviderType::TRMLabs => "TRM Labs",
            ProviderType::CipherTrace => "CipherTrace",
            ProviderType::Internal => "Internal",
        }
    }
}

/// Provider status
#[derive(Debug, Clone, Copy, PartialEq, Eq, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum ProviderStatus {
    /// Provider is active
    Active = 0,
    /// Provider is inactive
    Inactive = 1,
    /// Provider is degraded
    Degraded = 2,
    /// Provider is unavailable
    Unavailable = 3,
}

/// Provider health metrics
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct ProviderHealth {
    /// Provider type
    pub provider_type: ProviderType,
    /// Current status
    pub status: ProviderStatus,
    /// Average response time (ms)
    pub avg_response_time_ms: u64,
    /// Success rate (0-100)
    pub success_rate: u8,
    /// Last successful query timestamp
    pub last_success: i64,
    /// Last failed query timestamp
    pub last_failure: i64,
    /// Total queries
    pub total_queries: u64,
    /// Failed queries
    pub failed_queries: u64,
    /// Reserved space
    pub reserved: [u8; 32],
}

impl ProviderHealth {
    /// Create new provider health
    pub fn new(provider_type: ProviderType) -> Self {
        Self {
            provider_type,
            status: ProviderStatus::Active,
            avg_response_time_ms: 0,
            success_rate: 100,
            last_success: 0,
            last_failure: 0,
            total_queries: 0,
            failed_queries: 0,
            reserved: [0u8; 32],
        }
    }

    /// Record successful query
    pub fn record_success(&mut self, response_time_ms: u64) {
        self.total_queries += 1;
        self.last_success = Clock::default().unix_timestamp;

        // Update average response time
        if self.avg_response_time_ms == 0 {
            self.avg_response_time_ms = response_time_ms;
        } else {
            self.avg_response_time_ms = (self.avg_response_time_ms + response_time_ms) / 2;
        }
    }

    /// Record failed query
    pub fn record_failure(&mut self) {
        self.total_queries += 1;
        self.failed_queries += 1;
        self.last_failure = Clock::default().unix_timestamp;

        // Update success rate
        self.success_rate = ((self.total_queries - self.failed_queries) * 100 / self.total_queries) as u8;

        // Update status based on failures
        if self.success_rate < 50 {
            self.status = ProviderStatus::Unavailable;
        } else if self.success_rate < 80 {
            self.status = ProviderStatus::Degraded;
        }
    }

    /// Check if provider is healthy
    pub fn is_healthy(&self) -> bool {
        self.status == ProviderStatus::Active || self.status == ProviderStatus::Degraded
    }
}

/// Provider configuration
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct ProviderConfig {
    /// Provider type
    pub provider_type: ProviderType,
    /// Provider API endpoint
    pub endpoint: String,
    /// API key (should be stored securely)
    pub api_key_hash: [u8; 32],
    /// Weight for scoring (0-100)
    pub weight: u8,
    /// Whether enabled
    pub enabled: bool,
    /// Timeout in milliseconds
    pub timeout_ms: u64,
    /// Retry count
    pub retry_count: u8,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl ProviderConfig {
    /// Create new provider configuration
    pub fn new(provider_type: ProviderType, endpoint: String, weight: u8) -> Self {
        Self {
            provider_type,
            endpoint,
            api_key_hash: [0u8; 32],
            weight: weight.min(100),
            enabled: true,
            timeout_ms: MAX_RESPONSE_TIME_MS,
            retry_count: 3,
            reserved: [0u8; 64],
        }
    }

    /// Check if provider is configured
    pub fn is_configured(&self) -> bool {
        !self.endpoint.is_empty() && self.api_key_hash != [0u8; 32]
    }
}

/// Individual provider risk result
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct ProviderRiskResult {
    /// Provider type
    pub provider: ProviderType,
    /// Whether address is flagged
    pub flagged: bool,
    /// Risk score (0-100)
    pub risk_score: u8,
    /// Risk categories
    pub risk_categories: Vec<String>,
    /// Confidence (0-100)
    pub confidence: u8,
    /// Additional metadata
    pub metadata: HashMap<String, String>,
    /// Timestamp
    pub timestamp: i64,
    /// Query time (ms)
    pub query_time_ms: u64,
}

impl ProviderRiskResult {
    /// Create new provider result
    pub fn new(provider: ProviderType, flagged: bool, risk_score: u8) -> Self {
        Self {
            provider,
            flagged,
            risk_score: risk_score.min(100),
            risk_categories: Vec::new(),
            confidence: 75, // Default confidence
            metadata: HashMap::new(),
            timestamp: Clock::default().unix_timestamp,
            query_time_ms: 0,
        }
    }

    /// Add risk category
    pub fn add_category(&mut self, category: String) {
        self.risk_categories.push(category);
    }
}

/// Aggregated risk report
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct AggregatedRiskReport {
    /// Wallet address
    pub wallet: Pubkey,
    /// Overall risk score (0-100)
    pub risk_score: u8,
    /// Whether flagged
    pub flagged: bool,
    /// Number of providers that flagged
    pub flag_count: u8,
    /// Total providers queried
    pub total_providers: u8,
    /// Aggregated risk categories
    pub risk_categories: Vec<String>,
    /// Combined confidence (0-100)
    pub confidence: u8,
    /// Individual provider results
    pub provider_results: Vec<ProviderRiskResult>,
    /// Recommendations
    pub recommendations: Vec<String>,
    /// Timestamp
    pub timestamp: i64,
    /// Aggregator version
    pub version: u8,
}

impl AggregatedRiskReport {
    /// Create new aggregated report
    pub fn new(wallet: Pubkey) -> Self {
        Self {
            wallet,
            risk_score: 0,
            flagged: false,
            flag_count: 0,
            total_providers: 0,
            risk_categories: Vec::new(),
            confidence: 0,
            provider_results: Vec::new(),
            recommendations: Vec::new(),
            timestamp: Clock::default().unix_timestamp,
            version: 1,
        }
    }

    /// Check if report is valid
    pub fn is_valid(&self) -> bool {
        self.total_providers > 0 && self.confidence > 0
    }

    /// Generate recommendations based on results
    pub fn generate_recommendations(&mut self) {
        if self.flagged {
            self.recommendations.push("Manual review required - wallet flagged by risk providers".to_string());
        }

        if self.risk_score > 70 {
            self.recommendations.push("High risk score detected - consider additional verification".to_string());
        }

        if self.confidence < 50 {
            self.recommendations.push("Low confidence - recommend querying additional providers".to_string());
        }

        if self.risk_categories.contains(&"sanctions".to_string()) {
            self.recommendations.push("Sanctions risk detected - immediate review required".to_string());
        }

        if self.recommendations.is_empty() {
            self.recommendations.push("Standard monitoring recommended".to_string());
        }
    }
}

/// Aggregator configuration
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct AggregatorConfig {
    /// Minimum number of providers required
    pub min_providers: u8,
    /// Confidence threshold
    pub confidence_threshold: u8,
    /// Risk score threshold for flagging
    pub flag_threshold: u8,
    /// Whether to require majority flagging
    pub require_majority_flag: bool,
    /// Provider weights
    pub provider_weights: HashMap<ProviderType, u8>,
    /// Fallback enabled
    pub fallback_enabled: bool,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl Default for AggregatorConfig {
    fn default() -> Self {
        Self {
            min_providers: 2,
            confidence_threshold: DEFAULT_CONFIDENCE_THRESHOLD,
            flag_threshold: 50,
            require_majority_flag: true,
            provider_weights: HashMap::new(),
            fallback_enabled: true,
            reserved: [0u8; 64],
        }
    }
}

impl AggregatorConfig {
    /// Create new aggregator config
    pub fn new() -> Self {
        Self::default()
    }

    /// Add provider weight
    pub fn add_provider_weight(&mut self, provider: ProviderType, weight: u8) {
        self.provider_weights.insert(provider, weight.min(100));
    }

    /// Get provider weight
    pub fn get_weight(&self, provider: ProviderType) -> u8 {
        *self.provider_weights.get(&provider).unwrap_or(&75)
    }
}

/// Aggregator errors
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AggregatorError {
    /// No providers configured
    NoProviders = 0x6001,
    /// Provider unavailable
    ProviderUnavailable = 0x6002,
    /// Insufficient providers
    InsufficientProviders = 0x6003,
    /// All providers failed
    AllProvidersFailed = 0x6004,
    /// Invalid response
    InvalidResponse = 0x6005,
    /// Timeout
    Timeout = 0x6006,
    /// Rate limited
    RateLimited = 0x6007,
}

impl From<AggregatorError> for ProgramError {
    fn from(e: AggregatorError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

/// Risk data aggregator
pub struct RiskAggregator;

impl RiskAggregator {
    /// Aggregate risk from multiple providers
    ///
    /// This function queries multiple risk data providers and aggregates
    /// their results into a single risk assessment.
    ///
    /// # Arguments
    ///
    /// * `config` - Aggregator configuration
    /// * `wallet` - Wallet address to check
    /// * `provider_results` - Results from individual providers
    ///
    /// # Returns
    ///
    /// Aggregated risk report
    pub fn aggregate(
        config: &AggregatorConfig,
        wallet: Pubkey,
        provider_results: Vec<ProviderRiskResult>,
    ) -> Result<AggregatedRiskReport, ProgramError> {
        // Validate inputs
        if provider_results.is_empty() {
            return Err(AggregatorError::NoProviders.into());
        }

        // Filter to enabled results
        let valid_results: Vec<_> = provider_results.into_iter()
            .filter(|r| r.confidence > 0)
            .collect();

        if valid_results.len() < config.min_providers as usize {
            return Err(AggregatorError::InsufficientProviders.into());
        }

        // Calculate weighted risk score
        let mut total_weight: u32 = 0;
        let mut weighted_score: u32 = 0;

        for result in &valid_results {
            let weight = config.get_weight(result.provider) as u32;
            weighted_score += result.risk_score as u32 * weight;
            total_weight += weight;
        }

        let risk_score = if total_weight > 0 {
            (weighted_score / total_weight) as u8
        } else {
            0
        };

        // Determine flagging
        let flag_count = valid_results.iter().filter(|r| r.flagged).count() as u8;
        let total = valid_results.len() as u8;

        let flagged = if config.require_majority_flag {
            flag_count > total / 2
        } else {
            flag_count > 0 && risk_score >= config.flag_threshold
        };

        // Aggregate risk categories
        let mut all_categories: HashMap<String, u8> = HashMap::new();
        for result in &valid_results {
            for category in &result.risk_categories {
                *all_categories.entry(category.clone()).or_insert(0) += 1;
            }
        }

        let risk_categories: Vec<String> = all_categories
            .iter()
            .filter(|(_, count)| **count >= total / 2)
            .map(|(k, _)| k.clone())
            .collect();

        // Calculate confidence
        let confidence = if valid_results.is_empty() {
            0
        } else {
            (valid_results.iter().map(|r| r.confidence as u32).sum::<u32>() / valid_results.len() as u32) as u8
        };

        // Create report
        let mut report = AggregatedRiskReport {
            wallet,
            risk_score,
            flagged,
            flag_count,
            total_providers: total,
            risk_categories,
            confidence,
            provider_results: valid_results,
            recommendations: Vec::new(),
            timestamp: Clock::default().unix_timestamp,
            version: 1,
        };

        // Generate recommendations
        report.generate_recommendations();

        Ok(report)
    }

    /// Calculate risk score from raw provider data
    ///
    /// This is used when raw data needs to be converted to a standardized format.
    ///
    /// # Arguments
    ///
    /// * `raw_data` - Raw risk data from provider
    /// * `provider_type` - Provider type
    ///
    /// # Returns
    ///
    /// Standardized provider result
    pub fn normalize_provider_data(
        raw_data: &HashMap<String, String>,
        provider_type: ProviderType,
    ) -> Result<ProviderRiskResult, ProgramError> {
        let mut result = ProviderRiskResult::new(
            provider_type,
            false, // flagged
            0,     // risk_score
        );

        // Parse flagged status
        if let Some(flagged_str) = raw_data.get("flagged") {
            result.flagged = flagged_str == "true" || flagged_str == "1";
        }

        // Parse risk score
        if let Some(score_str) = raw_data.get("risk_score") {
            if let Ok(score) = score_str.parse::<u8>() {
                result.risk_score = score.min(100);
            }
        }

        // Parse confidence
        if let Some(conf_str) = raw_data.get("confidence") {
            if let Ok(conf) = conf_str.parse::<u8>() {
                result.confidence = conf.min(100);
            }
        }

        // Parse categories
        if let Some(cats_str) = raw_data.get("categories") {
            result.risk_categories = cats_str.split(',')
                .map(|s| s.trim().to_string())
                .filter(|s| !s.is_empty())
                .collect();
        }

        Ok(result)
    }

    /// Get fallback report when all providers fail
    ///
    /// When no provider data is available, this generates a conservative
    /// fallback report that defaults to higher risk.
    ///
    /// # Arguments
    ///
    /// * `wallet` - Wallet address
    ///
    /// # Returns
    ///
    /// Fallback risk report
    pub fn get_fallback_report(wallet: Pubkey) -> AggregatedRiskReport {
        let mut report = AggregatedRiskReport::new(wallet);

        // Conservative defaults
        report.risk_score = 50; // Medium risk
        report.flagged = false;
        report.flag_count = 0;
        report.total_providers = 0;
        report.confidence = 25; // Low confidence
        report.recommendations = vec![
            "No provider data available - manual review required".to_string(),
            "Treat as medium risk until provider data retrieved".to_string(),
        ];

        report
    }

    /// Check if result requires immediate action
    pub fn requires_immediate_action(report: &AggregatedRiskReport) -> bool {
        // Critical risk
        if report.risk_score >= 80 {
            return true;
        }

        // Multiple flags
        if report.flag_count >= 2 {
            return true;
        }

        // Sanctions category
        if report.risk_categories.contains(&"sanctions".to_string()) {
            return true;
        }

        false
    }

    /// Merge multiple reports
    pub fn merge_reports(reports: &[AggregatedRiskReport]) -> AggregatedRiskReport {
        if reports.is_empty() {
            return AggregatedRiskReport::new(Pubkey::default());
        }

        if reports.len() == 1 {
            return reports[0].clone();
        }

        // Get wallet from first report
        let wallet = reports[0].wallet;

        // Calculate average scores
        let total_score: u32 = reports.iter().map(|r| r.risk_score as u32).sum();
        let avg_score = (total_score / reports.len() as u32) as u8;

        // Count total flags
        let total_flags: u8 = reports.iter().map(|r| r.flag_count).sum();

        // Merge categories
        let mut all_categories: HashMap<String, u8> = HashMap::new();
        for report in reports {
            for cat in &report.risk_categories {
                *all_categories.entry(cat.clone()).or_insert(0) += 1;
            }
        }

        let risk_categories: Vec<String> = all_categories
            .keys()
            .cloned()
            .collect();

        // Calculate confidence
        let total_conf: u32 = reports.iter().map(|r| r.confidence as u32).sum();
        let avg_conf = (total_conf / reports.len() as u32) as u8;

        AggregatedRiskReport {
            wallet,
            risk_score: avg_score,
            flagged: total_flags > 0,
            flag_count: total_flags,
            total_providers: reports.iter().map(|r| r.total_providers).sum(),
            risk_categories,
            confidence: avg_conf,
            provider_results: Vec::new(),
            recommendations: reports[0].recommendations.clone(),
            timestamp: Clock::default().unix_timestamp,
            version: 1,
        }
    }

    /// Validate provider result
    pub fn validate_result(result: &ProviderRiskResult) -> bool {
        result.confidence > 0 &&
        result.risk_score <= 100 &&
        !result.risk_categories.iter().any(|c| c.is_empty())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_provider_health() {
        let mut health = ProviderHealth::new(ProviderType::Chainalysis);

        assert!(health.is_healthy());

        health.record_success(100);
        assert_eq!(health.total_queries, 1);
        assert_eq!(health.success_rate, 100);

        health.record_failure();
        assert_eq!(health.success_rate, 50);
    }

    #[test]
    fn test_provider_config() {
        let config = ProviderConfig::new(
            ProviderType::Chainalysis,
            "https://api.chainalysis.com".to_string(),
            80,
        );

        assert_eq!(config.provider_type, ProviderType::Chainalysis);
        assert!(config.enabled);
    }

    #[test]
    fn test_aggregator_config() {
        let mut config = AggregatorConfig::new();
        config.add_provider_weight(ProviderType::Chainalysis, 90);
        config.add_provider_weight(ProviderType::Elliptic, 80);

        assert_eq!(config.get_weight(ProviderType::Chainalysis), 90);
        assert_eq!(config.get_weight(ProviderType::TRMLabs), 75); // Default
    }

    #[test]
    fn test_aggregate_risk() {
        let config = AggregatorConfig::new();
        let wallet = Pubkey::new_from_array([1u8; 32]);

        let mut result1 = ProviderRiskResult::new(ProviderType::Chainalysis, true, 80);
        result1.confidence = 80;
        result1.add_category("high_risk".to_string());

        let mut result2 = ProviderRiskResult::new(ProviderType::Elliptic, false, 30);
        result2.confidence = 70;

        let report = RiskAggregator::aggregate(
            &config,
            wallet,
            vec![result1, result2],
        );

        assert!(report.is_ok());
        let report = report.unwrap();
        assert!(report.flagged);
        assert!(report.risk_score > 0);
    }

    #[test]
    fn test_fallback_report() {
        let wallet = Pubkey::new_from_array([1u8; 32]);
        let report = RiskAggregator::get_fallback_report(wallet);

        assert_eq!(report.risk_score, 50);
        assert!(!report.flagged);
        assert_eq!(report.confidence, 25);
    }

    #[test]
    fn test_requires_immediate_action() {
        let wallet = Pubkey::new_from_array([1u8; 32]);
        let mut report = AggregatedRiskReport::new(wallet);

        // Critical risk
        report.risk_score = 85;
        assert!(RiskAggregator::requires_immediate_action(&report));

        // Multiple flags
        report.risk_score = 50;
        report.flag_count = 2;
        assert!(RiskAggregator::requires_immediate_action(&report));

        // Sanctions
        report.flag_count = 1;
        report.risk_categories.push("sanctions".to_string());
        assert!(RiskAggregator::requires_immediate_action(&report));
    }

    #[test]
    fn test_normalize_provider_data() {
        let mut raw_data = HashMap::new();
        raw_data.insert("flagged".to_string(), "true".to_string());
        raw_data.insert("risk_score".to_string(), "75".to_string());
        raw_data.insert("confidence".to_string(), "85".to_string());
        raw_data.insert("categories".to_string(), "high_risk, gambling".to_string());

        let result = RiskAggregator::normalize_provider_data(&raw_data, ProviderType::TRMLabs);

        assert!(result.is_ok());
        let result = result.unwrap();
        assert!(result.flagged);
        assert_eq!(result.risk_score, 75);
        assert_eq!(result.confidence, 85);
        assert!(result.risk_categories.contains(&"high_risk".to_string()));
    }

    #[test]
    fn test_merge_reports() {
        let wallet = Pubkey::new_from_array([1u8; 32]);

        let mut report1 = AggregatedRiskReport::new(wallet);
        report1.risk_score = 60;
        report1.flag_count = 1;

        let mut report2 = AggregatedRiskReport::new(wallet);
        report2.risk_score = 40;
        report2.flag_count = 0;

        let merged = RiskAggregator::merge_reports(&[report1, report2]);

        assert_eq!(merged.risk_score, 50); // Average
        assert!(merged.flagged); // Has flags
    }
}
