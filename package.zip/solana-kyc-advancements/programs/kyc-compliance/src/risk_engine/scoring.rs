//! Risk Scoring Engine Module
//!
//! This module implements the core algorithmic engine that assigns real-time risk
//! scores to addresses within the compliance registry.
//!
//! ## Overview
//!
//! The scoring engine:
//! - Calculates risk scores based on multiple factors
//! - Provides real-time score updates
//! - Supports configurable scoring algorithms
//! - Maintains historical risk data
//! - Integrates with off-chain oracles for external data
//!
//! ## Scoring Factors
//!
//! The engine considers the following risk factors:
//! - Transaction history and patterns
//! - Counterparty risk analysis
//! - Geographic risk factors
//! - Historical compliance violations
//! - On-chain behavior patterns
//! - Protocol interaction risk
//!
//! ## Usage
//!
//! ```rust
//! use kyc_compliance::risk_engine::scoring::{RiskScorer, RiskScore, RiskLevel};
//!
//! let scorer = RiskScorer::new(config, oracle)?;
//! let score = scorer.calculate_score(wallet, factors)?;
//! ```

use solana_program::{
    account_info::AccountInfo,
    clock::Clock,
    entrypoint::ProgramResult,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::Sysvar,
};
use std::collections::HashMap;

/// Maximum number of historical score entries to keep
pub const MAX_HISTORY_ENTRIES: usize = 100;

/// Maximum risk score value
pub const MAX_RISK_SCORE: u32 = 10000; // 100.00 * 100

/// Minimum risk score value
pub const MIN_RISK_SCORE: u32 = 0;

/// Risk score threshold for high risk
pub const HIGH_RISK_THRESHOLD: u32 = 7500;

/// Risk score threshold for critical risk
pub const CRITICAL_RISK_THRESHOLD: u32 = 9000;

/// Risk levels based on score
#[derive(Debug, Clone, Copy, PartialEq, Eq, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum RiskLevel {
    /// No risk (0-2500)
    Low = 0,
    /// Low to moderate risk (2501-5000)
    Medium = 1,
    /// High risk (5001-7500)
    High = 2,
    /// Critical risk (7501-10000)
    Critical = 3,
}

impl RiskLevel {
    /// Get risk level from score
    pub fn from_score(score: u32) -> Self {
        if score <= 2500 {
            RiskLevel::Low
        } else if score <= 5000 {
            RiskLevel::Medium
        } else if score <= 7500 {
            RiskLevel::High
        } else {
            RiskLevel::Critical
        }
    }

    /// Get level name
    pub fn to_string(&self) -> &'static str {
        match self {
            RiskLevel::Low => "Low",
            RiskLevel::Medium => "Medium",
            RiskLevel::High => "High",
            RiskLevel::Critical => "Critical",
        }
    }

    /// Check if level requires manual review
    pub fn requires_manual_review(&self) -> bool {
        matches!(self, RiskLevel::High | RiskLevel::Critical)
    }
}

/// Risk factor types
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub enum RiskFactor {
    /// Transaction volume risk
    TransactionVolume = 0,
    /// Transaction frequency risk
    TransactionFrequency = 1,
    /// Counterparty risk
    CounterpartyRisk = 2,
    /// Geographic risk
    GeographicRisk = 3,
    /// Behavioral pattern risk
    BehavioralPattern = 4,
    /// Historical violation risk
    HistoricalViolation = 5,
    /// Protocol interaction risk
    ProtocolInteraction = 6,
    /// KYC status risk
    KycStatus = 7,
    /// Sanction list risk
    SanctionList = 8,
    /// Velocity risk (funds movement speed)
    Velocity = 9,
}

impl RiskFactor {
    /// Get all risk factors
    pub fn all() -> Vec<RiskFactor> {
        vec![
            RiskFactor::TransactionVolume,
            RiskFactor::TransactionFrequency,
            RiskFactor::CounterpartyRisk,
            RiskFactor::GeographicRisk,
            RiskFactor::BehavioralPattern,
            RiskFactor::HistoricalViolation,
            RiskFactor::ProtocolInteraction,
            RiskFactor::KycStatus,
            RiskFactor::SanctionList,
            RiskFactor::Velocity,
        ]
    }

    /// Get factor name
    pub fn to_string(&self) -> &'static str {
        match self {
            RiskFactor::TransactionVolume => "Transaction Volume",
            RiskFactor::TransactionFrequency => "Transaction Frequency",
            RiskFactor::CounterpartyRisk => "Counterparty Risk",
            RiskFactor::GeographicRisk => "Geographic Risk",
            RiskFactor::BehavioralPattern => "Behavioral Pattern",
            RiskFactor::HistoricalViolation => "Historical Violation",
            RiskFactor::ProtocolInteraction => "Protocol Interaction",
            RiskFactor::KycStatus => "KYC Status",
            RiskFactor::SanctionList => "Sanction List",
            RiskFactor::Velocity => "Velocity",
        }
    }
}

/// Individual risk factor data
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct FactorData {
    /// Factor type
    pub factor: RiskFactor,
    /// Score value (0-10000)
    pub score: u32,
    /// Confidence in score (0-100)
    pub confidence: u8,
    /// Data source
    pub source: String,
    /// Timestamp of assessment
    pub timestamp: i64,
    /// Additional metadata
    pub metadata: HashMap<String, String>,
}

impl FactorData {
    /// Create new factor data
    pub fn new(factor: RiskFactor, score: u32, confidence: u8, source: String) -> Self {
        Self {
            factor,
            score: score.min(MAX_RISK_SCORE),
            confidence: confidence.min(100),
            source,
            timestamp: Clock::default().unix_timestamp,
            metadata: HashMap::new(),
        }
    }

    /// Add metadata
    pub fn add_metadata(&mut self, key: String, value: String) {
        self.metadata.insert(key, value);
    }
}

/// Risk score result
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct RiskScore {
    /// Wallet address
    pub wallet: Pubkey,
    /// Overall risk score (0-10000)
    pub score: u32,
    /// Risk level
    pub level: RiskLevel,
    /// Individual factor scores
    pub factors: Vec<FactorData>,
    /// Confidence in assessment (0-100)
    pub confidence: u8,
    /// Requires manual review
    pub requires_review: bool,
    /// Timestamp of calculation
    pub timestamp: i64,
    /// Score version
    pub version: u8,
}

impl RiskScore {
    /// Create new risk score
    pub fn new(wallet: Pubkey, score: u32, factors: Vec<FactorData>) -> Self {
        let score = score.min(MAX_RISK_SCORE);
        let level = RiskLevel::from_score(score);

        // Calculate confidence
        let confidence = if factors.is_empty() {
            50
        } else {
            (factors.iter().map(|f| f.confidence as u32).sum::<u32>() / factors.len() as u32) as u8
        };

        Self {
            wallet,
            score,
            level,
            factors,
            confidence,
            requires_review: level.requires_manual_review(),
            timestamp: Clock::default().unix_timestamp,
            version: 1,
        }
    }

    /// Get score as percentage (0.00 - 100.00)
    pub fn score_percentage(&self) -> f64 {
        self.score as f64 / 100.0
    }

    /// Check if score is high risk or above
    pub fn is_high_risk(&self) -> bool {
        matches!(self.level, RiskLevel::High | RiskLevel::Critical)
    }

    /// Get top risk factors
    pub fn top_factors(&self, count: usize) -> Vec<&FactorData> {
        let mut sorted = self.factors.clone();
        sorted.sort_by(|a, b| b.score.cmp(&a.score));
        sorted.iter().take(count).collect()
    }
}

/// Historical score entry
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct ScoreHistoryEntry {
    /// Score value
    pub score: u32,
    /// Risk level
    pub level: RiskLevel,
    /// Timestamp
    pub timestamp: i64,
    /// Reason for change
    pub reason: String,
}

impl ScoreHistoryEntry {
    /// Create new history entry
    pub fn new(score: u32, level: RiskLevel, reason: String) -> Self {
        Self {
            score,
            level,
            timestamp: Clock::default().unix_timestamp,
            reason,
        }
    }
}

/// Risk score configuration
#[derive(Debug, Clone, solana_program::borsh::BorshSerialize, solana_program::borsh::BorshDeserialize)]
pub struct ScoringConfig {
    /// Weight for transaction volume factor
    pub weight_transaction_volume: f64,
    /// Weight for transaction frequency factor
    pub weight_transaction_frequency: f64,
    /// Weight for counterparty risk factor
    pub weight_counterparty_risk: f64,
    /// Weight for geographic risk factor
    pub weight_geographic_risk: f64,
    /// Weight for behavioral pattern factor
    pub weight_behavioral_pattern: f64,
    /// Weight for historical violation factor
    pub weight_historical_violation: f64,
    /// Weight for protocol interaction factor
    pub weight_protocol_interaction: f64,
    /// Weight for KYC status factor
    pub weight_kyc_status: f64,
    /// Weight for sanction list factor
    pub weight_sanction_list: f64,
    /// Weight for velocity factor
    pub weight_velocity: f64,
    /// Minimum confidence threshold
    pub min_confidence_threshold: u8,
    /// Auto-flag high risk
    pub auto_flag_high_risk: bool,
    /// Reserved space
    pub reserved: [u8; 64],
}

impl Default for ScoringConfig {
    fn default() -> Self {
        Self {
            weight_transaction_volume: 0.15,
            weight_transaction_frequency: 0.10,
            weight_counterparty_risk: 0.20,
            weight_geographic_risk: 0.10,
            weight_behavioral_pattern: 0.15,
            weight_historical_violation: 0.10,
            weight_protocol_interaction: 0.05,
            weight_kyc_status: 0.10,
            weight_sanction_list: 0.03,
            weight_velocity: 0.02,
            min_confidence_threshold: 50,
            auto_flag_high_risk: true,
            reserved: [0u8; 64],
        }
    }
}

impl ScoringConfig {
    /// Get weight for a factor
    pub fn get_weight(&self, factor: RiskFactor) -> f64 {
        match factor {
            RiskFactor::TransactionVolume => self.weight_transaction_volume,
            RiskFactor::TransactionFrequency => self.weight_transaction_frequency,
            RiskFactor::CounterpartyRisk => self.weight_counterparty_risk,
            RiskFactor::GeographicRisk => self.weight_geographic_risk,
            RiskFactor::BehavioralPattern => self.weight_behavioral_pattern,
            RiskFactor::HistoricalViolation => self.weight_historical_violation,
            RiskFactor::ProtocolInteraction => self.weight_protocol_interaction,
            RiskFactor::KycStatus => self.weight_kyc_status,
            RiskFactor::SanctionList => self.weight_sanction_list,
            RiskFactor::Velocity => self.weight_velocity,
        }
    }

    /// Validate weights sum to approximately 1.0
    pub fn validate_weights(&self) -> bool {
        let sum = self.weight_transaction_volume
            + self.weight_transaction_frequency
            + self.weight_counterparty_risk
            + self.weight_geographic_risk
            + self.weight_behavioral_pattern
            + self.weight_historical_violation
            + self.weight_protocol_interaction
            + self.weight_kyc_status
            + self.weight_sanction_list
            + self.weight_velocity;

        (sum - 1.0).abs() < 0.01
    }

    /// Create custom configuration
    pub fn with_custom_weights(
        weights: HashMap<RiskFactor, f64>,
    ) -> Result<Self, ProgramError> {
        let mut config = Self::default();

        if let Some(w) = weights.get(&RiskFactor::TransactionVolume) {
            config.weight_transaction_volume = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::TransactionFrequency) {
            config.weight_transaction_frequency = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::CounterpartyRisk) {
            config.weight_counterparty_risk = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::GeographicRisk) {
            config.weight_geographic_risk = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::BehavioralPattern) {
            config.weight_behavioral_pattern = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::HistoricalViolation) {
            config.weight_historical_violation = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::ProtocolInteraction) {
            config.weight_protocol_interaction = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::KycStatus) {
            config.weight_kyc_status = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::SanctionList) {
            config.weight_sanction_list = *w;
        }
        if let Some(w) = weights.get(&RiskFactor::Velocity) {
            config.weight_velocity = *w;
        }

        if !config.validate_weights() {
            return Err(ProgramError::Custom(0x5001)); // InvalidWeights
        }

        Ok(config)
    }
}

/// Risk scorer implementation
pub struct RiskScorer;

impl RiskScorer {
    /// Calculate risk score from factor data
    ///
    /// This function computes the weighted average of all risk factors
    /// to produce an overall risk score.
    ///
    /// # Arguments
    ///
    /// * `config` - Scoring configuration with weights
    /// * `factors` - Vector of factor data
    ///
    /// # Returns
    ///
    /// Calculated risk score
    pub fn calculate_score(
        config: &ScoringConfig,
        factors: &[FactorData],
    ) -> Result<RiskScore, ProgramError> {
        // Validate inputs
        if factors.is_empty() {
            return Err(ProgramError::Custom(0x5002)); // NoFactorsProvided
        }

        // Calculate weighted score
        let mut total_weighted_score: f64 = 0.0;
        let mut total_weight: f64 = 0.0;

        for factor_data in factors {
            let weight = config.get_weight(factor_data.factor);
            let normalized_score = factor_data.score as f64 / MAX_RISK_SCORE as f64;

            total_weighted_score += normalized_score * weight;
            total_weight += weight;
        }

        // Normalize by total weight used
        let final_score = if total_weight > 0.0 {
            (total_weighted_score / total_weight * MAX_RISK_SCORE as f64) as u32
        } else {
            0
        };

        // Cap at maximum
        let final_score = final_score.min(MAX_RISK_SCORE);

        Ok(RiskScore::new(
            factors[0].factor.get_wallet_from_metadata(),
            final_score,
            factors.to_vec(),
        ))
    }

    /// Calculate individual factor score
    ///
    /// This function computes the score for a specific factor based on
    /// raw data.
    ///
    /// # Arguments
    ///
    /// * `factor` - Risk factor type
    /// * `raw_value` - Raw value to assess
    /// * `source` - Data source identifier
    ///
    /// # Returns
    ///
    /// Factor data with calculated score
    pub fn calculate_factor_score(
        factor: RiskFactor,
        raw_value: f64,
        source: String,
    ) -> FactorData {
        let score = match factor {
            RiskFactor::TransactionVolume => Self::score_transaction_volume(raw_value),
            RiskFactor::TransactionFrequency => Self::score_transaction_frequency(raw_value),
            RiskFactor::CounterpartyRisk => Self::score_counterparty_risk(raw_value),
            RiskFactor::GeographicRisk => Self::score_geographic_risk(raw_value),
            RiskFactor::BehavioralPattern => Self::score_behavioral_pattern(raw_value),
            RiskFactor::HistoricalViolation => Self::score_historical_violation(raw_value),
            RiskFactor::ProtocolInteraction => Self::score_protocol_interaction(raw_value),
            RiskFactor::KycStatus => Self::score_kyc_status(raw_value),
            RiskFactor::SanctionList => Self::score_sanction_list(raw_value),
            RiskFactor::Velocity => Self::score_velocity(raw_value),
        };

        let confidence = Self::calculate_factor_confidence(factor, raw_value);

        FactorData::new(factor, score, confidence, source)
    }

    /// Score transaction volume risk
    fn score_transaction_volume(volume: f64) -> u32 {
        // Higher volume = higher risk (up to a point)
        let score = if volume < 1000.0 {
            volume * 0.5 // 0-500
        } else if volume < 10000.0 {
            500.0 + (volume - 1000.0) * 0.05 // 500-950
        } else if volume < 100000.0 {
            950.0 + (volume - 10000.0) * 0.0005 // 950-995
        } else {
            995.0 // Cap at high risk
        };

        score as u32
    }

    /// Score transaction frequency risk
    fn score_transaction_frequency(frequency: f64) -> u32 {
        // Higher frequency = higher risk
        let score = if frequency < 1.0 {
            frequency * 1000.0 // 0-1000
        } else if frequency < 10.0 {
            1000.0 + (frequency - 1.0) * 100.0 // 1000-1900
        } else {
            1900.0 + (frequency - 10.0) * 10.0 // Cap at high risk
        };

        (score.min(2000.0) as u32)
    }

    /// Score counterparty risk
    fn score_counterparty_risk(risk_score: f64) -> u32 {
        // Directly use risk score (0-100)
        (risk_score * 100.0) as u32
    }

    /// Score geographic risk
    fn score_geographic_risk(risk_score: f64) -> u32 {
        (risk_score * 100.0) as u32
    }

    /// Score behavioral pattern risk
    fn score_behavioral_pattern(pattern_score: f64) -> u32 {
        (pattern_score * 100.0) as u32
    }

    /// Score historical violation risk
    fn score_historical_violation(violation_count: f64) -> u32 {
        // More violations = higher risk
        let score = if violation_count == 0.0 {
            0.0
        } else if violation_count == 1.0 {
            500.0
        } else if violation_count < 5.0 {
            500.0 + (violation_count - 1.0) * 125.0 // 500-1000
        } else {
            1000.0 // Maximum
        };

        score as u32
    }

    /// Score protocol interaction risk
    fn score_protocol_interaction(risk_score: f64) -> u32 {
        (risk_score * 100.0) as u32
    }

    /// Score KYC status
    fn score_kyc_status(kyc_level: f64) -> u32 {
        // Higher KYC level = lower risk
        // kyc_level: 0 = none, 1 = basic, 2 = standard, 3 = enhanced
        let risk = match kyc_level as u32 {
            0 => 1000.0, // No KYC = high risk
            1 => 600.0,  // Basic KYC = medium-high
            2 => 300.0,  // Standard KYC = medium
            _ => 100.0,  // Enhanced = low
        };

        risk as u32
    }

    /// Score sanction list check
    fn score_sanction_list(flagged: f64) -> u32 {
        // 0 = not flagged, 1 = flagged
        if flagged > 0.5 {
            1000.0 as u32 // Maximum risk
        } else {
            0
        }
    }

    /// Score velocity risk
    fn score_velocity(velocity: f64) -> u32 {
        // Velocity = funds movement speed
        let score = if velocity < 1.0 {
            velocity * 500.0
        } else if velocity < 5.0 {
            500.0 + (velocity - 1.0) * 125.0
        } else {
            1000.0
        };

        score as u32
    }

    /// Calculate confidence for factor score
    fn calculate_factor_confidence(factor: RiskFactor, raw_value: f64) -> u8 {
        // Higher data quality = higher confidence
        match factor {
            RiskFactor::SanctionList => 95, // Authoritative source
            RiskFactor::KycStatus => 90,    // Verified data
            RiskFactor::HistoricalViolation => 85,
            RiskFactor::CounterpartyRisk => 75,
            RiskFactor::GeographicRisk => 70,
            RiskFactor::TransactionVolume => 80,
            RiskFactor::TransactionFrequency => 80,
            RiskFactor::ProtocolInteraction => 65,
            RiskFactor::BehavioralPattern => 60,
            RiskFactor::Velocity => 70,
        }
    }

    /// Check if score requires action
    pub fn requires_action(score: &RiskScore, config: &ScoringConfig) -> bool {
        // Check if score exceeds threshold
        if score.score >= CRITICAL_RISK_THRESHOLD {
            return true;
        }

        // Check confidence threshold
        if score.confidence < config.min_confidence_threshold {
            return true;
        }

        // Check if high risk and auto-flag enabled
        if config.auto_flag_high_risk && score.level == RiskLevel::High {
            return true;
        }

        false
    }

    /// Calculate trend from history
    pub fn calculate_trend(history: &[ScoreHistoryEntry]) -> &'static str {
        if history.len() < 2 {
            return "stable";
        }

        let recent: Vec<_> = history.iter().rev().take(5).collect();
        let avg_recent: f64 = recent.iter().map(|e| e.score as f64).sum::<f64>() / recent.len() as f64;

        if avg_recent < 3000.0 {
            "improving"
        } else if avg_recent > 7000.0 {
            "worsening"
        } else {
            "stable"
        }
    }
}

/// Extension trait for RiskFactor
trait RiskFactorExt {
    fn get_wallet_from_metadata(&self) -> Pubkey;
}

impl RiskFactorExt for RiskFactor {
    fn get_wallet_from_metadata(&self) -> Pubkey {
        // This would normally extract from factor metadata
        // Placeholder return
        Pubkey::default()
    }
}

/// Errors for scoring operations
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ScoringError {
    /// Invalid weights
    InvalidWeights = 0x5001,
    /// No factors provided
    NoFactorsProvided = 0x5002,
    /// Factor not found
    FactorNotFound = 0x5003,
    /// Score calculation error
    CalculationError = 0x5004,
    /// History full
    HistoryFull = 0x5005,
}

impl From<ScoringError> for ProgramError {
    fn from(e: ScoringError) -> Self {
        ProgramError::Custom(e as u32)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_risk_level_from_score() {
        assert_eq!(RiskLevel::from_score(0), RiskLevel::Low);
        assert_eq!(RiskLevel::from_score(2500), RiskLevel::Low);
        assert_eq!(RiskLevel::from_score(2501), RiskLevel::Medium);
        assert_eq!(RiskLevel::from_score(5000), RiskLevel::Medium);
        assert_eq!(RiskLevel::from_score(5001), RiskLevel::High);
        assert_eq!(RiskLevel::from_score(7500), RiskLevel::High);
        assert_eq!(RiskLevel::from_score(7501), RiskLevel::Critical);
        assert_eq!(RiskLevel::from_score(10000), RiskLevel::Critical);
    }

    #[test]
    fn test_scoring_config_default() {
        let config = ScoringConfig::default();
        assert!(config.validate_weights());
    }

    #[test]
    fn test_transaction_volume_scoring() {
        let score = RiskScorer::score_transaction_volume(500.0);
        assert!(score < 500);

        let high_score = RiskScorer::score_transaction_volume(1000000.0);
        assert!(high_score > 900);
    }

    #[test]
    fn test_ky() {
        letc_status_scoring no_kyc = RiskScorer::score_kyc_status(0.0);
        assert_eq!(no_kyc, 1000);

        let basic_kyc = RiskScorer::score_kyc_status(1.0);
        assert_eq!(basic_kyc, 600);

        let enhanced_kyc = RiskScorer::score_kyc_status(3.0);
        assert_eq!(enhanced_kyc, 100);
    }

    #[test]
    fn test_factor_data_creation() {
        let factor = FactorData::new(
            RiskFactor::TransactionVolume,
            500,
            80,
            "test_source".to_string(),
        );

        assert_eq!(factor.score, 500);
        assert_eq!(factor.confidence, 80);
    }

    #[test]
    fn test_risk_score_creation() {
        let wallet = Pubkey::new_from_array([1u8; 32]);
        let factors = vec![
            FactorData::new(RiskFactor::TransactionVolume, 500, 80, "source".to_string()),
            FactorData::new(RiskFactor::KycStatus, 300, 90, "source".to_string()),
        ];

        let score = RiskScorer::calculate_score(&ScoringConfig::default(), &factors);
        assert!(score.is_ok());
    }

    #[test]
    fn test_requires_action() {
        let config = ScoringConfig::default();
        let wallet = Pubkey::new_from_array([1u8; 32]);

        // Critical score
        let critical = RiskScore::new(wallet, 9500, vec![]);
        assert!(RiskScorer::requires_action(&critical, &config));

        // Low score
        let low = RiskScore::new(wallet, 1000, vec![]);
        assert!(!RiskScorer::requires_action(&low, &config));
    }

    #[test]
    fn test_sanction_list_scoring() {
        let flagged = RiskScorer::score_sanction_list(1.0);
        assert_eq!(flagged, 1000);

        let not_flagged = RiskScorer::score_sanction_list(0.0);
        assert_eq!(not_flagged, 0);
    }
}
