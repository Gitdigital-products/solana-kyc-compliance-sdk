
# Badge Authority

Badges define permissions.

## Badge Schema

badge_id
name
capabilities
proof_hash
issuer
timestamp

## Example Badges

Contributor
Builder
Maintainer
Treasurer
Agent Operator
