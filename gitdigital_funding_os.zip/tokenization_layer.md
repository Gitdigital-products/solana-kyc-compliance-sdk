
# Funding Tokenization Layer

Purpose: Convert funding contributions into governance tokens.

## Token Model

Symbol: GDF (GitDigital Funding Token)

Distribution:

Contributor Tokens = contribution_usd * token_rate

## Utility

Governance voting
Grant allocation
Reputation boost
