
# GitHub Project Board #9 Integration

GitHub milestones act as the canonical milestone registry.

## Milestone Schema

milestone_id
title
funding_required
badge_required
status

Funding OS automatically updates milestone status through GitHub API.
