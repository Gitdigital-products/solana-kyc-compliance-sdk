
# Railway Deployment

## Services

funding-engine
zk-prover
badge-authority
dashboard-api
notion-sync
agent-controller

## Environment Variables

SOLANA_RPC
OPEN_COLLECTIVE_KEY
AURORA_ZK_ENDPOINT
GITHUB_TOKEN
NOTION_API_KEY
OPENCLAW_SECRET
