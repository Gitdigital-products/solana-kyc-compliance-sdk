
# Aurora ZK Integration

## Proof Goals

Prove:
- funding >= milestone requirement
- treasury integrity
- contributor eligibility

Hide:
- individual donor identity
- private allocations

## Circuits

- funding_threshold.circuit
- treasury_integrity.circuit
- contributor_eligibility.circuit
- badge_unlock.circuit
