
# System Architecture

## High-Level Architecture

Contributors → Treasuries → Funding Engine → zk Layer → Governance → Agents → Dashboard

Treasuries:
- Open Collective (USD)
- Solana wallet (SOL/USDC)

Core runtime services operate on Railway.

## Core Services

- funding-engine
- zk-prover
- badge-authority
- treasury-aggregator
- milestone-resolver
- dashboard-api
- notion-sync
- agent-controller

## Event Bus

Primary events:

funding.received
threshold.reached
milestone.unlocked
zk.proof.generated
badge.awarded
agent.authorized
