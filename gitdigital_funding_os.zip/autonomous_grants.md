
# Autonomous Grant Engine

AI agents automatically allocate funds once zk proofs confirm milestone completion.

## Workflow

milestone_completed
   ↓
zk proof verified
   ↓
agent evaluates grant rules
   ↓
treasury payout executed

## Agent Inputs

treasury health
reputation scores
milestone priority
