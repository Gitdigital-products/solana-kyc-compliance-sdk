
# Funding Engine

Unified treasury aggregator combining:

USD (Open Collective)
SOL
USDC

## Unified Funding Formula

unified_funding = usd_total + sol_usd + usdc_usd

## Milestone Threshold Logic

if unified_funding >= milestone.target:
    unlock_milestone()

## Treasury Health Score

health = (liquidity / burn_rate) * contributor_growth
