
# Reputation Graph

Reputation aggregates badge history, contribution history, and milestone work.

## Reputation Score

score = contribution_weight + milestone_weight + badge_weight

## Graph Model

Nodes:
- contributors
- badges
- milestones

Edges:
- earned
- contributed
- approved
