# Privacy & Data Handling Policy (Draft)

## Data collected
- Minimal PII fields collected for KYC: full name, government ID type (hash), verification status, provider ID.
- We **do not** store raw government ID images in the on-chain registry.

## Purpose
- Store KYC verification results and metadata for AML compliance and transfer gating.

## Retention
- KYC verification metadata: 5 years after account closure (adjust per jurisdiction).
- Audit logs: 7 years.

## Access & controls
- Role-based access to PII and audit logs.
- All access is logged and auditable.

## Rights
- Data subjects may request correction or deletion; deletion requests may be limited by AML retention obligations.

## Contact
- privacy@gitdigital-products.example
