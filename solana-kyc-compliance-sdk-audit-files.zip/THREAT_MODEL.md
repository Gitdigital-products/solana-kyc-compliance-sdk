# Threat Model (summary)

## Assets
- On-chain registry state
- Registry authority private keys
- Off-chain KYC PII storage
- SDK distribution artifacts and release signing keys

## Attackers
- Rogue/compromised KYC provider
- Key compromise (registry authority)
- Supply-chain attack (npm/crates dependency compromise)
- Insider threats

## Mitigations (high level)
- Multisig for critical registry authority operations
- GPG-signed releases & verifiable builds
- Dependency scans and pinning
- RBAC and audit logging for PII access
