# Upgrade & Migration Policy

- On-chain programs should be upgradeable only through a multisig-controlled upgrade authority.
- Each upgrade requires:
  1. Verifiable build for the new artifact.
  2. Migration script in `migrations/` with test coverage.
  3. Rollback plan and stale-state detection.
