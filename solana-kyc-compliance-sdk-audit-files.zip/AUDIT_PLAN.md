# AUDIT Plan for Solana KYC Compliance SDK

## Purpose / Scope
This plan defines scope, deliverables, timelines, and artifacts for an external audit.
Scope includes:
- On-chain Rust programs (all crates)
- TypeScript SDK and wasm bindings
- Server components (signer server / registry API)
- CI build and verifiable-build scripts
- Threat model and operational runbooks

## Deliverables expected from auditor
- Executive summary
- Detailed findings (with severity)
- Repro steps for each vulnerability
- Fix recommendations and code-level patches where feasible
- Re-test report after fixes

## Artifacts to provide to auditor
- `dist/` release artifacts and checksums
- Docker build context (ci/Dockerfile)
- Access to testnet / staging environment
- Logs and metrics for a sample 30-day window (anonymized PII)

## Timeline (example)
- Kickoff & scoping: 1 week
- Static + dependency analysis: 1 week
- Manual code review & dynamic testing: 2 weeks
- Fuzzing & exploit dev: 1 week
- Reporting & remediation validation: 1-2 weeks

## Suggested audit firms (shortlist)
- Trail of Bits — deep systems + crypto expertise.
- Least Authority — privacy- and security-focused audits.
- OpenZeppelin — smart-contract & ecosystem experience.
- Kudelski Security — enterprise audits and penetration tests.

(Pick 2 vendors to run parallel scoping; license & NDA required.)

## Communication & NDA
- Provide auditor with scoped NDA (template available in `OPERATIONAL/`).
- Use ephemeral testnet accounts and scrub PII from logs if possible.

## Post-audit: next steps
- Triage findings by severity, schedule hotfix releases.
- Run regression tests and re-run CI `verifiable_build`.
- Publish a public audit summary (redacted) and remediation timeline.
