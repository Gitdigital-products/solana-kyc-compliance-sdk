# Verifiable Builds

This document describes how to produce deterministic, verifiable build artifacts for the
Solana on-chain program and SDK so third parties can verify that the published on-chain
binary matches the repository source.

## Overview
- Builds run inside a pinned Docker image with exact toolchain versions.
- Build script produces:
  - program .so (BPF shared object)
  - sha256 checksums file (dist/checksums.txt)
  - GPG-signed artifact metadata (dist/metadata.json.asc)

## Quick verification steps (auditor)
1. `git clone --recurse-submodules <repo>`
2. `./scripts/verifiable_build.sh --verify`
3. Confirm checksums match release artifacts and GPG signature verifies.

## Requirements
- Docker installed (version pinned in CI).
- GPG public key for release signing (available in repo `RELEASES/`).
- Network access to crates.io/npm (CI will have cached artifacts where possible).

## Scripts
- `scripts/verifiable_build.sh` creates reproducible builds and stores checksums in `dist/`.
- CI will call the same script and upload `dist/checksums.txt` as build artifact.

## Notes
Replace toolchain versions in `ci/Dockerfile` with the desired pinned versions.
