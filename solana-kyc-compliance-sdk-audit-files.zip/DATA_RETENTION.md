# Data Retention

- KYC verification metadata: retain for 5 years after account closure.
- Audit logs: retain for 7 years.
- Backups: encrypted daily backups retained for 90 days in hot storage, 3 years in cold storage.
