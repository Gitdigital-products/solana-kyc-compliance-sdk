# Deployment Runbook (summary)

## Preflight
- Verify `ci/verifiable-build.yml` produced `dist/checksums.txt`.
- Confirm release signature and GPG key availability.

## Deploy steps (example)
1. Run verifiable build locally or in CI.
2. Upload program to devnet and run integration tests.
3. Promote to mainnet via upgrade authority (multisig recommended).
4. Run sanity checks and monitor metrics for at least 24 hours.

## Rollback
- Keep a snapshot of last-known-good `program_id` and backup of registry DB.
- To rollback, deploy previous verified artifact and restore off-chain snapshots.
