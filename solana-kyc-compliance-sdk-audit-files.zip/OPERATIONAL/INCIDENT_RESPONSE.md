# Incident Response (summary)

## Lost registry authority key
- Immediately pause registry operations (if possible).
- Rotate authority keys via multisig process.
- Notify impacted parties and schedule remediation.

## Data breach (PII)
- Follow jurisdictional breach disclosure rules.
- Engage legal and forensic team.
