# Examples

This folder should contain minimal end-to-end examples:
- web/ : wasm + browser example performing KYC flow.
- backend/ : node example demonstrating provider signing and registry update.
- integration-tests/ : scripts that run a local validator, deploy program, and exercise transfer hooks.
