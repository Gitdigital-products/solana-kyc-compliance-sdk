#!/usr/bin/env bash
set -euo pipefail
# Basic verifiable build script.
# Usage:
#  ./scripts/verifiable_build.sh            -> produce artifacts
#  ./scripts/verifiable_build.sh --verify   -> verify checksums against ./dist/checksums.txt

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST_DIR="$REPO_ROOT/dist"
mkdir -p "$DIST_DIR"

echo "Starting verifiable build..."

# Example: build Rust on-chain program (anchor / cargo)
echo "Building on-chain program..."
(cd "$REPO_ROOT/program" && cargo build --release --locked)
# Assume compiled bpf object at program/target/release/libprogram.so or similar.
# Copy artifact (adjust path to your build output)
cp -v "$REPO_ROOT/program/target/release/libprogram.so" "$DIST_DIR/" || true

# Build TypeScript SDK (optional)
if [ -d "$REPO_ROOT/sdk" ]; then
  echo "Building TypeScript SDK..."
  (cd "$REPO_ROOT/sdk" && npm ci && npm run build)
  # copy built SDK bundle if exists
  cp -v "$REPO_ROOT/sdk/dist" -r "$DIST_DIR/sdk" || true
fi

# Produce checksums
echo "Producing checksums..."
(cd "$DIST_DIR" && find . -type f -print0 | sort -z | xargs -0 sha256sum > checksums.txt)

# Sign metadata (requires GPG private key available in environment)
if [ -n "${GPG_SIGN_KEY:-}" ]; then
  echo "Signing checksums with GPG key $GPG_SIGN_KEY..."
  (cd "$DIST_DIR" && gpg --default-key "$GPG_SIGN_KEY" --armor --output checksums.txt.asc --detach-sign checksums.txt) || true
else
  echo "GPG_SIGN_KEY not set; skipping GPG signature step."
fi

echo "Verifiable build complete. Artifacts in $DIST_DIR"
