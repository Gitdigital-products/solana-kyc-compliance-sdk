Place these audit files into repository root. Update contact emails and keys before publishing.
