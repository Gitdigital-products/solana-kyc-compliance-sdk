# SECURITY

## Reporting a Vulnerability
Please report suspected security issues to: security@gitdigital-products.example
If possible, include a minimal repro and your PGP-encrypted contact details.

## Supported Versions
- Rust on-chain program: 0.1.x
- TypeScript SDK: 0.1.x

## Response process
1. Acknowledge within 48 hours.
2. Triage severity (CVSS-style).
3. Provide mitigation timeline and patch PR.
4. Publish patched release and advisory.

## Disclosure policy
- We follow coordinated disclosure; if you need a bounty, please include suggested terms.
- For high-severity issues we may request a short embargo to prepare fixes and notify stakeholders.

## Contacts
- Primary: security@gitdigital-products.example
- PGP key: <INSERT PGP FINGERPRINT HERE>
