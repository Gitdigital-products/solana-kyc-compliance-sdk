
# Automation Engine

The automation engine listens for events from:

- GitHub milestones
- Crowdfunding thresholds
- Membership tiers
- Subscription payments
- Contributor agreements
- Grant approvals

Events trigger workflows for:

- Grants
- Invoices
- Payroll
- Advances
- Loans
- Contracts
- Bills
- Affiliate payouts
