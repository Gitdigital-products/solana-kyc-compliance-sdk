
# Workflow Event Triggers

Events that trigger automation:

milestone.completed
goal.reached
agreement.signed
phrase.confirmed
crowdfunding.threshold
membership.activated
subscription.paid
support.tier.upgraded
grant.approved
invoice.submitted
payroll.cycle
loan.approved
advance.requested
contract.completed
bill.received
