
# Leaderboard System

Tracks top contributors across multiple dimensions.

Leaderboards:

Top Funding
Top Contributions
Top Commits
Top Affiliates
Top Grant Partners

Data Sources:
- GitHub commits
- Open Collective contributions
- Solana transactions
- Affiliate tracking
- Grant participation

Ranking Score:

score =
(contribution_usd * 0.5) +
(commit_count * 0.2) +
(affiliate_referrals * 0.2) +
(grant_participation * 0.1)
