
# Payout Engine

Automated financial flows once conditions are met.

Supported payout types:

- Grant payouts
- Contributor payments
- Affiliate commissions
- Payroll
- Contractor invoices
- Loans and advances
- Partner revenue shares

Execution chain:

Trigger → Validation → zk Proof → Badge Authority Approval → Treasury Payout
