
# GitDigital Funding OS v2

Expanded Funding OS including automation workflows, payout engines,
leaderboards, and GitHub-triggered financial operations.

Key Features
- Multi-chain treasury aggregation
- Badge-governed automation
- Aurora zk proof validation
- AI agent orchestration
- GitHub milestone-triggered payouts
- Contributor leaderboards
- Automated grants, invoices, payroll, contracts, and bills
